import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// In-memory store for technician triage tickets (from WhatsApp AI & direct emergency dispatch)
interface TechnicianTicket {
  id: string;
  source: 'whatsapp_ai' | 'emergency_sos' | 'web_booking';
  customerName: string;
  phone: string;
  area: string;
  systemSize: string;
  inverterBrand: string;
  serviceType: string;
  urgency: 'EMERGENCY' | 'HIGH' | 'NORMAL';
  description: string;
  technicianNotes: string;
  assignedTechnician?: string;
  status: 'PENDING' | 'ASSIGNED' | 'EN_ROUTE' | 'ON_SITE' | 'RESOLVED';
  createdAt: string;
  etaMinutes?: number;
}

const mockInitialTickets: TechnicianTicket[] = [
  {
    id: 'TK-KHI-8901',
    source: 'whatsapp_ai',
    customerName: 'Asadullah Khan',
    phone: '+92 300 2489110',
    area: 'DHA Phase 6, Karachi',
    systemSize: '15 kW On-Grid',
    inverterBrand: 'Huawei Sun2000',
    serviceType: 'Solar Deep Cleaning & De-ionized Wash',
    urgency: 'HIGH',
    description: 'Severe dust buildup after sandstorm; inverter generation dropped from 65 kWh/day to 42 kWh/day.',
    technicianNotes: 'Requires 2-man wash team with RO de-ionized water tank and rotary soft nylon brush. Double-story roof with parapet.',
    assignedTechnician: 'Engr. Zeeshan Haider (Crew 2)',
    status: 'ASSIGNED',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    etaMinutes: 45
  },
  {
    id: 'TK-KHI-8902',
    source: 'emergency_sos',
    customerName: 'Rashid Mehmood (Al-Karam Weaving)',
    phone: '+92 321 8290344',
    area: 'Korangi Industrial Area, Sector 7-A',
    systemSize: '50 kW Commercial',
    inverterBrand: 'Inverex Nitrox 50kW',
    serviceType: 'Emergency Inverter Repair',
    urgency: 'EMERGENCY',
    description: 'Inverter error Fault F08 (DC Bus Overvoltage). Complete factory solar shutdown during peak production.',
    technicianNotes: 'Emergency high-voltage testing kit, spare surge protectors, and bypass fuses required. Prioritize immediate dispatch.',
    assignedTechnician: 'Senior Engr. Tariq Mehmood (Rapid SOS Van #1)',
    status: 'EN_ROUTE',
    createdAt: new Date(Date.now() - 1800000).toISOString(),
    etaMinutes: 22
  },
  {
    id: 'TK-KHI-8903',
    source: 'web_booking',
    customerName: 'Dr. Ayesha Siddiqui',
    phone: '+92 333 9128472',
    area: 'Bahria Town Karachi, Precinct 10-A',
    systemSize: '10 kW Hybrid with Battery',
    inverterBrand: 'Knox Krypton 10kW',
    serviceType: 'Comprehensive System Optimization Audit',
    urgency: 'NORMAL',
    description: 'Annual scheduled thermographic drone audit + string open-circuit voltage calibration before summer peak.',
    technicianNotes: 'FLIR Thermal imaging camera required for micro-crack and hotspot scan. Client requested morning 10:00 AM slot.',
    assignedTechnician: 'Engr. Bilal Farooq',
    status: 'PENDING',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  }
];

let tickets: TechnicianTicket[] = [...mockInitialTickets];

// Initialize Gemini SDK if API key is provided
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// REST API for tickets & Meta Business Suite CRM
app.get('/api/tickets', (_req, res) => {
  res.json({ success: true, tickets });
});

app.post('/api/tickets', (req, res) => {
  const newTicket: TechnicianTicket = {
    id: `TK-KHI-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: new Date().toISOString(),
    status: 'PENDING',
    ...req.body,
  };
  tickets.unshift(newTicket);
  res.status(201).json({ success: true, ticket: newTicket });
});

app.patch('/api/tickets/:id', (req, res) => {
  const { id } = req.params;
  const index = tickets.findIndex((t) => t.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, error: 'Ticket not found' });
  }
  tickets[index] = { ...tickets[index], ...req.body };
  res.json({ success: true, ticket: tickets[index] });
});

// Gemini-powered WhatsApp AI Concierge Endpoint
app.post('/api/gemini/whatsapp-chat', async (req, res) => {
  try {
    const { messages, userProfile } = req.body;
    const conversation = messages || [];
    const latestUserMsg = conversation.length > 0 ? conversation[conversation.length - 1].content : '';

    const systemInstruction = `
You are "LightningBot", the friendly, expert AI WhatsApp Concierge for "⚡ LIGHTNING ENERGY SOLUTIONS" (Karachi, Pakistan).
Your company is Karachi's premier "One-Window Solar Solution" providing professional solar services for residential & commercial customers.

YOUR 4 CORE SERVICES & SPECIFIC DIAGNOSTIC QUESTIONS:
Whenever a client inquires about a service, warmly engage them and ask the relevant diagnostic questions in a friendly, conversational way (do not interrogate all at once; ask 2-3 at a time or in a natural conversational flow):

1️⃣ SOLAR PANEL CLEANING:
Ask about:
- Water availability on site (e.g. tap water / water tank available on roof)?
- Electric power supply available on roof (for pressure washer / rotary tools)?
- Walkway / Roof access (safe stairs, ladder, adequate walking space between panel rows)?
- Location in Karachi (e.g. DHA, Clifton, Gulshan, Bahria Town, Korangi, etc.)?
- Floor / Roof height (Ground, 1st floor, 2nd floor, or multi-story)?
- System capacity (kW or approximate number of panels)?

2️⃣ TROUBLESHOOTING & REPAIRS:
Ask about:
- Inverter brand & model (Inverex, Huawei, Knox, Growatt, Fronius, Sungrow, etc.)?
- Error code or warning light displayed (e.g. Fault 08, F01, red warning light, complete shutdown)?
- Issue symptoms (sudden tripping, burning smell, zero production in bright sun, sparking)?
- Location in Karachi & urgency level (Emergency 45-min SOS vs scheduled visit)?

3️⃣ PREVENTATIVE MAINTENANCE:
Ask about:
- Age of the system & date of last servicing?
- Specific need (thermographic drone hotspot inspection, string voltage balancing, inverter terminal torque check, or Annual Maintenance Contract AMC)?
- System capacity & Karachi area?

4️⃣ TURNKEY SOLAR INSTALLATION:
Ask about:
- Current monthly K-Electric bill in PKR or monthly units consumed?
- Roof type & area (RCC concrete slab, metal shed, available square feet)?
- Desired system type (On-Grid with Net Metering vs Hybrid with lithium battery storage)?
- Location in Karachi?

CRITICAL TONE & LANGUAGE MATCHING:
- Always use the EXACT same language and tone the client uses!
- If the customer writes in English: Respond in polished, warm, professional English.
- If the customer writes in Roman Urdu (e.g., "Bhai solar panels clean karwane hain..."): Respond in natural, polite Roman Urdu (e.g., "Walaikum Assalam! ⚡ Lightning Energy Solutions me khushamdeed! Karachi me hamari de-ionized wash team hazir hai. Kuch basic cheezain bata dijiye...").
- If the customer writes in Urdu script: Respond in polite Urdu script.

CONCLUDING THE CONVERSATION & BULLETED SUMMARY:
Once the client provides details, your reply MUST:
1. Conclude the conversation warmly (e.g. "JazakAllah! Hamari technical team Karachi me ready hai. Yeh rahi aapki inquiry summary:").
2. Present the collected information in clean, highlighted bullet points:
   ⚡ LIGHTNING ENERGY SOLUTIONS - INQUIRY SUMMARY
   • Service: [1️⃣ Cleaning | 2️⃣ Troubleshooting | 3️⃣ Maintenance | 4️⃣ Installation]
   • Location: [Karachi Area & Floor]
   • System Capacity: [kW / Panels]
   • Water on Site: [Yes / No / Tank on roof]
   • Electric Supply: [Available / Not available]
   • Walkway / Access: [Easy stairs / Ladder / Narrow]
   • Inverter / Details: [Brand / Error code / Notes]
3. Inform them that this summary can be sent directly to your official WhatsApp (+92 312 2443449) for instant quotation & slot reservation.

4. Output a clean JSON block at the very end tagged as \`\`\`json:
{
  "hasTriageData": true,
  "customerName": "Customer Name or Client",
  "phone": "+92 312 2443449",
  "area": "Karachi Area",
  "floor": "Roof Floor",
  "systemSize": "e.g. 10 kW",
  "waterOnSite": "Yes/No",
  "electricSupply": "Yes/No",
  "walkwayAccess": "Good/Ladder/Narrow",
  "inverterBrand": "e.g. Inverex / Huawei",
  "serviceType": "Solar Panel Cleaning | Troubleshooting | Maintenance | Installation",
  "urgency": "EMERGENCY | HIGH | NORMAL",
  "technicianNotes": "Clean bullet points of technical details for Karachi technician dispatch"
}
`;

    let generatedReply: string | null = null;

    if (ai) {
      try {
        const promptParts = [
          {
            text: `Current Karachi Time: ${new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Karachi' })}, Location: Karachi, Pakistan.\n` +
                  `Conversation History:\n` +
                  conversation.map((m: any) => `${m.role === 'user' ? 'Customer' : 'SolarBot'}: ${m.content}`).join('\n') +
                  `\nCustomer: ${latestUserMsg}\nSolarBot:`
          }
        ];

        // 4-second timeout promise
        const timeoutPromise = new Promise<null>((_, reject) =>
          setTimeout(() => reject(new Error('AI generation timeout')), 4000)
        );

        const aiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptParts,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        }).then(res => res.text || null);

        generatedReply = await Promise.race([aiPromise, timeoutPromise]);
      } catch (err) {
        console.warn('Gemini call timed out or failed, using domain expert fallback:', (err as any)?.message);
      }
    }

    if (generatedReply) {
      const replyText = generatedReply;
      let triageData: any = null;
      const jsonMatch = replyText.match(/```json\s*([\s\S]*?)\s*```/);
      let cleanText = replyText;

      if (jsonMatch && jsonMatch[1]) {
        try {
          triageData = JSON.parse(jsonMatch[1]);
          cleanText = replyText.replace(/```json\s*[\s\S]*?\s*```/, '').trim();
          
          if (triageData && triageData.serviceType && triageData.urgency) {
            const ticket: TechnicianTicket = {
              id: `TK-KHI-${Math.floor(1000 + Math.random() * 9000)}`,
              source: 'whatsapp_ai',
              customerName: triageData.customerName || userProfile?.name || 'WhatsApp Client',
              phone: triageData.phone || userProfile?.phone || '+92 300 0000000',
              area: triageData.area || 'Karachi (Area to be confirmed)',
              systemSize: triageData.systemSize || 'Residential System',
              inverterBrand: triageData.inverterBrand || 'Standard On-Grid/Hybrid',
              serviceType: triageData.serviceType || 'Solar Service Request',
              urgency: triageData.urgency === 'EMERGENCY' ? 'EMERGENCY' : (triageData.urgency === 'HIGH' ? 'HIGH' : 'NORMAL'),
              description: latestUserMsg,
              technicianNotes: triageData.technicianNotes || 'Generated by SolarCare WhatsApp AI Concierge',
              status: 'PENDING',
              createdAt: new Date().toISOString(),
              etaMinutes: triageData.urgency === 'EMERGENCY' ? 35 : undefined,
            };
            tickets.unshift(ticket);
            triageData.ticketId = ticket.id;
          }
        } catch {
          // ignore parsing error
        }
      }

      return res.json({
        success: true,
        reply: cleanText,
        triageData,
      });
    } else {
      // Intelligent fallback if GEMINI_API_KEY is not configured
      const lower = latestUserMsg.toLowerCase();
      let reply = "";
      let triageData: any = null;

      if (lower.includes('emergency') || lower.includes('urgent') || lower.includes('smoke') || lower.includes('spark') || lower.includes('fault') || lower.includes('error') || lower.includes('troubleshoot')) {
        reply = "Assalam-o-Alaikum! ⚡ Lightning Energy Solutions (One-Window Solar Solution Karachi) has logged your request with **EMERGENCY / HIGH PRIORITY**.\n\nOur rapid troubleshooting team resolves inverter trips (F08, Fault 01, overload) and electrical hazards within 35–45 minutes across Karachi. Could you please share your exact area (e.g. DHA, Clifton, Gulshan, Korangi) and inverter brand/error code so our technician arrives equipped?";
        triageData = {
          hasTriageData: true,
          customerName: userProfile?.name || 'Emergency Customer',
          phone: userProfile?.phone || '+92 312 2443449',
          area: 'Karachi Central/South',
          systemSize: '10 kW Solar Array',
          inverterBrand: 'Inverex / Huawei / Knox',
          serviceType: 'Troubleshooting & Inverter Diagnostics',
          urgency: 'EMERGENCY',
          technicianNotes: '⚡ Lightning Energy Solutions Emergency Troubleshooting: Inverter error code/blackout. Dispatch mobile testing van.',
        };
      } else if (lower.includes('clean') || lower.includes('wash') || lower.includes('dust') || lower.includes('dhona')) {
        reply = "Assalam-o-Alaikum! ⚡ Welcome to Lightning Energy Solutions. Karachi's coastal humidity and traffic soot creates a sticky dirt film that reduces solar generation by 20% to 35%! We use 0-TDS de-ionized purified water and scratch-free rotary brushes to restore 100% peak output.\n\nCould you please share your system size in kW and your location in Karachi? I will calculate your instant assessment & quotation right now!";
        triageData = {
          hasTriageData: true,
          customerName: userProfile?.name || 'Karachi Client',
          phone: userProfile?.phone || '+92 312 2443449',
          area: 'DHA / Clifton / Gulshan',
          systemSize: '10 kW (approx 18-22 panels)',
          inverterBrand: 'Residential Inverter',
          serviceType: 'Solar Panel Cleaning',
          urgency: 'HIGH',
          technicianNotes: '⚡ Lightning Energy Solutions: Solar Panel Cleaning. Purified 0-TDS wash and before/after generation check.',
        };
      } else if (lower.includes('install') || lower.includes('setup') || lower.includes('npt') || lower.includes('fitting')) {
        reply = "Assalam-o-Alaikum! ⚡ Looking to install a new solar energy system? Lightning Energy Solutions is your One-Window Solar Solution in Karachi for Turnkey On-Grid and Hybrid Solar Installations. We handle high-yield Tier-1 panels, inverters, structure, and K-Electric net metering documentation.\n\nWhat is your monthly electricity bill or desired capacity (e.g. 5kW, 10kW, 20kW+)?";
        triageData = {
          hasTriageData: true,
          customerName: userProfile?.name || 'Solar Installation Prospect',
          phone: userProfile?.phone || '+92 312 2443449',
          area: 'Karachi (Area to be confirmed)',
          systemSize: 'Turnkey Installation Request',
          inverterBrand: 'Tier-1 Hybrid / On-Grid',
          serviceType: 'Installation',
          urgency: 'NORMAL',
          technicianNotes: '⚡ Lightning Energy Solutions: New Installation Assessment & Site Feasibility required.',
        };
      } else if (lower.includes('price') || lower.includes('rate') || lower.includes('cost') || lower.includes('kharcha')) {
        reply = "Assalam-o-Alaikum! ⚡ Lightning Energy Solutions offers transparent, competitive rates in Karachi:\n• 1️⃣ Solar Panel Cleaning: from PKR 4,500 (includes 0-TDS purified wash)\n• 2️⃣ Troubleshooting: from PKR 5,500 (rapid on-site diagnostic)\n• 3️⃣ Maintenance: bi-annual or annual contracts from PKR 8,500\n• 4️⃣ Installation: tailored turnkey packages with K-Electric net metering.\n\nWould you like an on-site assessment for your location?";
      } else {
        reply = "Assalam-o-Alaikum! ⚡ Welcome to **Lightning Energy Solutions** — Your One-Window Solar Solution in Karachi!\n\nWe provide professional residential & commercial services:\n1️⃣ Solar Panel Cleaning\n2️⃣ Troubleshooting\n3️⃣ Maintenance\n4️⃣ Installation\n\nHow can we help you today? Feel free to ask any question or request an on-site assessment!";
      }

      if (triageData) {
        const ticket: TechnicianTicket = {
          id: `TK-KHI-${Math.floor(1000 + Math.random() * 9000)}`,
          source: 'whatsapp_ai',
          customerName: triageData.customerName,
          phone: triageData.phone,
          area: triageData.area,
          systemSize: triageData.systemSize,
          inverterBrand: triageData.inverterBrand,
          serviceType: triageData.serviceType,
          urgency: triageData.urgency as 'EMERGENCY' | 'HIGH' | 'NORMAL',
          description: latestUserMsg,
          technicianNotes: triageData.technicianNotes,
          status: 'PENDING',
          createdAt: new Date().toISOString(),
          etaMinutes: triageData.urgency === 'EMERGENCY' ? 40 : undefined,
        };
        tickets.unshift(ticket);
        triageData.ticketId = ticket.id;
      }

      return res.json({
        success: true,
        reply,
        triageData,
      });
    }
  } catch (error: any) {
    console.error('WhatsApp AI Chat error:', error);
    res.status(500).json({
      success: false,
      reply: "Assalam-o-Alaikum! Our dispatch server is online. Please let us know your location in Karachi and service requirement, and our team will attend to you immediately.",
      error: error?.message,
    });
  }
});

app.get('/download-zip', (_req, res) => {
  const zipPath = path.resolve(process.cwd(), 'public', 'lightning-energy-solutions.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'lightning-energy-solutions.zip');
  } else {
    res.status(404).send('ZIP file not found');
  }
});

async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';
  const distIndex = path.resolve(process.cwd(), 'dist', 'index.html');

  if (!isDev && fs.existsSync(distIndex)) {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(distIndex);
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lightning Energy Solutions server running on port ${PORT}`);
  });
}

startServer();
