export interface KarachiArea {
  id: string;
  name: string;
  zone: 'South' | 'East' | 'Central' | 'Malir' | 'Korangi' | 'West';
  avgSoilingRate: number; // % generation drop per 10 days without cleaning due to local dust/soot
}

export interface SolarService {
  id: string;
  name: string;
  tagline: string;
  priceStartingPKR: number;
  duration: string;
  bestFor: string;
  features: string[];
  recommendedInterval: string;
  badge?: string;
}

export interface DemoSolarSystem {
  id: string;
  name: string;
  clientName: string;
  location: string;
  zone: string;
  capacityKW: number;
  panelsCount: number;
  inverterModel: string;
  systemType: 'On-Grid' | 'Hybrid' | 'Commercial Industrial';
  installationDate: string;
  currentOutputKW: number;
  dailyYieldKWh: number;
  monthlySavingsPKR: number;
  dustSoilingLossPercent: number; // e.g. 21.5%
  lastCleanedDate: string;
  nextRecommendedCleanDate: string;
  inverterHealthScore: number; // 0 - 100
  gridVoltage: number;
  gridFrequency: number;
  mppt1Volts: number;
  mppt2Volts: number;
  inverterTempC: number;
  batterySOC?: number;
  history: ServiceRecord[];
}

export interface ServiceRecord {
  id: string;
  date: string;
  type: string;
  technicianName: string;
  efficiencyBefore: number;
  efficiencyAfter: number;
  notes: string;
  photoBeforeUrl?: string;
  photoAfterUrl?: string;
  reportUrl?: string;
}

export interface ScheduledAlert {
  id: string;
  title: string;
  category: 'DUST_CLEANING' | 'INVERTER_HEALTH' | 'WEATHER' | 'ANNUAL_AMC';
  urgency: 'HIGH' | 'MEDIUM' | 'INFO';
  description: string;
  systemName: string;
  actionLabel: string;
  actionType: 'BOOK_CLEAN' | 'EMERGENCY_REPAIR' | 'VIEW_METRICS';
  dateGenerated: string;
  isRead: boolean;
}

export interface TechnicianTicket {
  id: string;
  source: 'whatsapp_ai' | 'emergency_sos' | 'web_booking';
  customerName: string;
  phone: string;
  area: string;
  floor?: string;
  systemSize: string;
  waterOnSite?: string;
  electricSupply?: string;
  walkwayAccess?: string;
  inverterBrand: string;
  serviceType: string;
  urgency: 'EMERGENCY' | 'HIGH' | 'NORMAL';
  description: string;
  technicianNotes: string;
  assignedTechnician?: string;
  status: 'PENDING' | 'ASSIGNED' | 'EN_ROUTE' | 'ON_SITE' | 'RESOLVED';
  createdAt: string;
  etaMinutes?: number;
}
