import React, { useState } from 'react';
import { 
  Bell, 
  Check, 
  Clock, 
  Wind, 
  AlertCircle, 
  Smartphone, 
  Sparkles, 
  Calendar, 
  Sliders, 
  ShieldCheck,
  Send,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { SCHEDULED_ALERTS } from '../data/solarData';
import { ScheduledAlert } from '../types';

interface AutomatedAlertsSectionProps {
  onScheduleCleaning: (systemName: string) => void;
  onRequestEmergency: () => void;
}

export const AutomatedAlertsSection: React.FC<AutomatedAlertsSectionProps> = ({
  onScheduleCleaning,
  onRequestEmergency
}) => {
  const [alerts, setAlerts] = useState<ScheduledAlert[]>(SCHEDULED_ALERTS);
  const [whatsappAlertsEnabled, setWhatsappAlertsEnabled] = useState<boolean>(true);
  const [smsAlertsEnabled, setSmsAlertsEnabled] = useState<boolean>(true);
  const [washInterval, setWashInterval] = useState<'biweekly' | 'monthly' | 'bimonthly'>('monthly');
  const [notificationPhone, setNotificationPhone] = useState<string>('+92 300 2489110');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulatedNotice, setSimulatedNotice] = useState<string | null>(null);

  const handleMarkAsRead = (id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isRead: true } : a))
    );
  };

  const handleSimulateAlert = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const newAlert: ScheduledAlert = {
        id: `alert-${Date.now()}`,
        title: 'Karachi Sand Wind Event: Efficiency Dropped to 74.2%',
        category: 'DUST_CLEANING',
        urgency: 'HIGH',
        description: 'Sensor detected sharp particulate build-up on Clifton & DHA installations following evening sea breeze gusts. Automatic wash slot reserved for tomorrow 09:30 AM.',
        systemName: 'Your Monitored Array',
        actionLabel: 'Confirm Tomorrow 09:30 AM Slot',
        actionType: 'BOOK_CLEAN',
        dateGenerated: 'Just now',
        isRead: false
      };
      setAlerts((prev) => [newAlert, ...prev]);
      setIsSimulating(false);
      setSimulatedNotice('Simulated Alert dispatched via WhatsApp & In-App notification system!');
      setTimeout(() => setSimulatedNotice(null), 4000);
    }, 800);
  };

  const unreadCount = alerts.filter((a) => !a.isRead).length;

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/90 backdrop-blur-xl p-6 lg:p-8 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold uppercase mb-2">
            <Bell className="w-3.5 h-3.5" />
            Predictive AI & Scheduled Maintenance Engine
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Automated Scheduled Maintenance Alerts
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Real-time proactive triggers monitoring Karachi dust index, weather trends, and bi-monthly washing intervals.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400">Active Alerts:</span>
            <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold font-mono">
              {unreadCount} Unread
            </span>
          </div>

          <button
            onClick={handleSimulateAlert}
            disabled={isSimulating}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700 active:scale-95 disabled:opacity-50"
          >
            {isSimulating ? 'Triggering...' : '⚡ Test Alert Dispatch'}
          </button>
        </div>
      </div>

      {simulatedNotice && (
        <div className="mt-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{simulatedNotice}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
        {/* Left: Active Alerts Feed */}
        <div className="lg:col-span-7 space-y-4">
          <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            Upcoming Scheduled Events & Sensor Warnings
          </h3>

          <div className="space-y-3.5">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                  !alert.isRead
                    ? 'bg-slate-950/80 border-amber-500/40 shadow-lg shadow-amber-950/10'
                    : 'bg-slate-950/40 border-slate-800 opacity-80'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      alert.urgency === 'HIGH'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : alert.urgency === 'MEDIUM'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                    }`}>
                      {alert.category === 'DUST_CLEANING' ? (
                        <Wind className="w-4 h-4" />
                      ) : alert.category === 'INVERTER_HEALTH' ? (
                        <AlertCircle className="w-4 h-4" />
                      ) : (
                        <Bell className="w-4 h-4" />
                      )}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-bold text-white">
                          {alert.title}
                        </h4>
                        {!alert.isRead && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 uppercase">
                            New
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {alert.systemName} • <span className="font-mono text-slate-500">{alert.dateGenerated}</span>
                      </p>
                    </div>
                  </div>

                  {!alert.isRead && (
                    <button
                      onClick={() => handleMarkAsRead(alert.id)}
                      className="text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors shrink-0"
                    >
                      Dismiss
                    </button>
                  )}
                </div>

                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  {alert.description}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <button
                    onClick={() => {
                      if (alert.actionType === 'BOOK_CLEAN') {
                        onScheduleCleaning(alert.systemName);
                      } else if (alert.actionType === 'EMERGENCY_REPAIR') {
                        onRequestEmergency();
                      }
                      handleMarkAsRead(alert.id);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md active:scale-95"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    {alert.actionLabel}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <span className="text-[11px] text-slate-500">
                    Auto-synced with Karachi Weather & Inverter API
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Automation Settings & Channels */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 space-y-5">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              Automated Notification Preferences
            </h3>

            {/* Notification Channels */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-2.5">
                  <span className="text-lg">💬</span>
                  <div>
                    <p className="text-xs font-bold text-white">WhatsApp Automated Alerts</p>
                    <p className="text-[11px] text-slate-400">Receive actionable alerts with 1-click booking</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setWhatsappAlertsEnabled(!whatsappAlertsEnabled)}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    whatsappAlertsEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-2.5">
                  <span className="text-lg">📱</span>
                  <div>
                    <p className="text-xs font-bold text-white">SMS Critical Broadcasts</p>
                    <p className="text-[11px] text-slate-400">Emergency inverter trips & severe weather</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSmsAlertsEnabled(!smsAlertsEnabled)}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    smsAlertsEnabled ? 'bg-sky-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                </button>
              </div>
            </div>

            {/* Phone Number Input */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Registered Contact for Automated Dispatch:
              </label>
              <input
                type="text"
                value={notificationPhone}
                onChange={(e) => setNotificationPhone(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>

            {/* Cleaning Frequency Cadence */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                Automated Wash Schedule Interval for Karachi Climate:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setWashInterval('biweekly')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all text-center ${
                    washInterval === 'biweekly'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  Bi-Weekly (14d)
                  <span className="block text-[10px] text-slate-500 mt-0.5">Heavy Soot</span>
                </button>

                <button
                  onClick={() => setWashInterval('monthly')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all text-center ${
                    washInterval === 'monthly'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  Monthly (30d)
                  <span className="block text-[10px] text-emerald-400 mt-0.5">Recommended</span>
                </button>

                <button
                  onClick={() => setWashInterval('bimonthly')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all text-center ${
                    washInterval === 'bimonthly'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  Bi-Monthly (60d)
                  <span className="block text-[10px] text-slate-500 mt-0.5">Low Dust Area</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
              💡 <strong>Smart Karachi Algorithm:</strong> If our sensors or regional PM2.5 monitoring detect a sandstorm or coastal salt fog event, an alert will trigger automatically regardless of your selected interval.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
