import React from 'react';
import { 
  Sparkles, 
  ShieldAlert, 
  ArrowRight, 
  Calculator, 
  CheckCircle2, 
  Zap, 
  Wind, 
  ShieldCheck, 
  Gauge, 
  Clock,
  Layers,
  MapPin,
  Download
} from 'lucide-react';

interface HeroSectionProps {
  onOpenEmergency: () => void;
  onOpenWhatsApp: () => void;
  onScrollToCalculator: () => void;
  onScrollToDashboard: () => void;
  onOpenExport?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenEmergency,
  onOpenWhatsApp,
  onScrollToCalculator,
  onScrollToDashboard,
  onOpenExport,
}) => {
  return (
    <section className="relative pt-10 pb-20 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-6xl h-96 radial-amber-glow pointer-events-none" />
      <div className="absolute top-48 right-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Karachi Specialization Pill */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/40 text-xs text-amber-300 font-bold shadow-xl backdrop-blur-md">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
            <span>⚡ LIGHTNING ENERGY SOLUTIONS • One-Window Solar Solution Karachi</span>
          </div>
        </div>

        {/* Main Headline */}
        <div className="text-center max-w-4xl mx-auto space-y-5">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.12]">
            ⚡ LIGHTNING ENERGY SOLUTIONS <br />
            <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-emerald-400 bg-clip-text text-transparent">
              One-Window Solar Solution
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-medium leading-relaxed">
            Professional solar services for residential & commercial customers in Karachi.
            Restoring peak solar yields, rapid 45-min troubleshooting, and turnkey installations.
          </p>

          {/* 4 Pillars Interactive Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-3xl mx-auto pt-2">
            <div className="bg-slate-900/90 border border-amber-500/30 p-2.5 rounded-xl text-center">
              <span className="text-sm font-bold text-amber-400 block">1️⃣ Solar Panel Cleaning</span>
              <span className="text-[11px] text-slate-400">0-TDS Purified De-ionized</span>
            </div>
            <div className="bg-slate-900/90 border border-rose-500/30 p-2.5 rounded-xl text-center">
              <span className="text-sm font-bold text-rose-400 block">2️⃣ Troubleshooting</span>
              <span className="text-[11px] text-slate-400">Inverter & Wiring Diagnostics</span>
            </div>
            <div className="bg-slate-900/90 border border-sky-500/30 p-2.5 rounded-xl text-center">
              <span className="text-sm font-bold text-sky-400 block">3️⃣ Maintenance</span>
              <span className="text-[11px] text-slate-400">Drone Thermography & AMCs</span>
            </div>
            <div className="bg-slate-900/90 border border-emerald-500/30 p-2.5 rounded-xl text-center">
              <span className="text-sm font-bold text-emerald-400 block">4️⃣ Installation</span>
              <span className="text-[11px] text-slate-400">Turnkey On-Grid & Hybrid</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
            <a
              href="https://wa.me/923122443449?text=Assalam-o-Alaikum%20Lightning%20Energy%20Solutions!%20I%20would%20like%20to%20request%20an%20assessment%20and%20quotation%20for%20my%20solar%20system%20in%20Karachi."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-7 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-2xl transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              <span className="text-xl">💬</span>
              <span>WhatsApp Us: 0312 2443449</span>
            </a>

            <button
              onClick={onScrollToCalculator}
              className="w-full sm:w-auto px-6 py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-2xl transition-all shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              <Calculator className="w-5 h-5" />
              <span>Calculate Savings & Book</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={onOpenEmergency}
              className="w-full sm:w-auto px-6 py-4 bg-rose-600/90 hover:bg-rose-600 text-white font-black rounded-2xl transition-all shadow-xl shadow-rose-950/60 border border-rose-500/50 flex items-center justify-center gap-2 active:scale-[0.98] group"
            >
              <ShieldAlert className="w-5 h-5 text-rose-300 group-hover:scale-110 transition-transform" />
              <span>SOS Troubleshooting (45m)</span>
            </button>
          </div>

          {/* GitHub / Hosting ZIP Folder Download Callout */}
          <div className="w-full max-w-2xl mx-auto mt-6 p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-emerald-500/20 border-2 border-amber-500/60 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left shadow-2xl">
            <div className="flex items-center gap-3">
              <span className="text-3xl p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">📦</span>
              <div>
                <div className="inline-flex items-center gap-2 px-2 py-0.5 rounded bg-amber-500/30 text-amber-300 font-extrabold text-[11px] mb-1">
                  GitHub & Vercel Free Live Folder
                </div>
                <h4 className="text-base font-extrabold text-white">Yahan Se Project Ka ZIP Folder Download Karein</h4>
                <p className="text-xs text-slate-300">Yeh wahi code folder hai jo aapko GitHub par upload karna hai</p>
              </div>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <a
                href="/download-zip"
                download="lightning-energy-solutions.zip"
                className="flex-1 sm:flex-none px-5 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/30 active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>Download ZIP (Click Here)</span>
              </a>
              {onOpenExport && (
                <button
                  onClick={onOpenExport}
                  className="px-3.5 py-3 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold rounded-xl border border-slate-700 transition-colors"
                >
                  Guide
                </button>
              )}
            </div>
          </div>

          {/* Social Links & Location Bar */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-300 pt-3">
            <span className="flex items-center gap-1 font-semibold text-amber-400">
              📍 Karachi Coverage
            </span>
            <span>•</span>
            <a 
              href="https://www.facebook.com/share/18i1okkFZ9/" 
              target="_blank" 
              rel="noreferrer"
              className="hover:text-blue-400 font-semibold underline flex items-center gap-1"
            >
              Facebook Official Page
            </a>
            <span>•</span>
            <a 
              href="https://www.instagram.com/lightning_energy_solutions?srtk=Nm8wZHJiZzZxMnFp" 
              target="_blank" 
              rel="noreferrer"
              className="hover:text-pink-400 font-semibold underline flex items-center gap-1"
            >
              Instagram @lightning_energy_solutions
            </a>
          </div>
        </div>

        {/* 4 Hero Highlight Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-14">
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md relative overflow-hidden group hover:border-amber-500/40 transition-colors">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">Panels Washed in Karachi</span>
              <Sparkles className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-3xl font-extrabold text-white font-mono mt-2">
              4,850+
            </p>
            <p className="text-xs text-slate-400 mt-1">
              DHA, Clifton, Bahria, Korangi
            </p>
          </div>

          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md relative overflow-hidden group hover:border-emerald-500/40 transition-colors">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">Average Output Restored</span>
              <Zap className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-3xl font-extrabold text-emerald-400 font-mono mt-2">
              +28.4%
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Recovered from heavy coastal dust
            </p>
          </div>

          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md relative overflow-hidden group hover:border-rose-500/40 transition-colors">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">Emergency SOS Response</span>
              <Clock className="w-4 h-4 text-rose-400" />
            </div>
            <p className="text-3xl font-extrabold text-rose-400 font-mono mt-2">
              45 Mins
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Rapid mobile diagnostic vans
            </p>
          </div>

          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md relative overflow-hidden group hover:border-sky-500/40 transition-colors">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">Live System Telemetry</span>
              <Gauge className="w-4 h-4 text-sky-400" />
            </div>
            <p className="text-3xl font-extrabold text-white font-mono mt-2">
              99.8%
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Client inverter uptime guarantee
            </p>
          </div>
        </div>

        {/* Karachi Neighborhood Quick Selector Bar */}
        <div className="mt-8 p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-400 font-medium">
            <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Active Karachi Service Coverage:</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[
              'DHA Phases 1-8',
              'Clifton Blocks 1-9',
              'Gulshan-e-Iqbal',
              'PECHS & Tariq Rd',
              'Bahria Town Karachi',
              'North Nazimabad',
              'Korangi Industrial',
              'SITE Area',
              'Malir Cantt'
            ].map((loc) => (
              <span
                key={loc}
                className="px-2.5 py-1 rounded-lg bg-slate-900 text-slate-300 border border-slate-800 font-medium"
              >
                {loc}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
