import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Zap, 
  Sun, 
  Wind, 
  BatteryCharging, 
  Gauge, 
  History, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Sliders, 
  Download,
  Eye,
  Calendar,
  Layers,
  Thermometer,
  ShieldAlert
} from 'lucide-react';
import { DEMO_SYSTEMS } from '../data/solarData';
import { DemoSolarSystem } from '../types';

interface PerformanceDashboardProps {
  onRequestWash: (system: DemoSolarSystem) => void;
  onRequestEmergency: (system: DemoSolarSystem) => void;
}

export const PerformanceDashboard: React.FC<PerformanceDashboardProps> = ({
  onRequestWash,
  onRequestEmergency
}) => {
  const [selectedSystemId, setSelectedSystemId] = useState<string>(DEMO_SYSTEMS[0].id);
  const [activeTab, setActiveTab] = useState<'realtime' | 'history' | 'dust_comparison'>('realtime');
  const [showDownloadFeedback, setShowDownloadFeedback] = useState<boolean>(false);
  const [sliderPosition, setSliderPosition] = useState<number>(50);

  // Live fluctuating power output simulation
  const [liveKW, setLiveKW] = useState<number>(DEMO_SYSTEMS[0].currentOutputKW);

  const currentSystem = DEMO_SYSTEMS.find((s) => s.id === selectedSystemId) || DEMO_SYSTEMS[0];

  useEffect(() => {
    setLiveKW(currentSystem.currentOutputKW);
  }, [selectedSystemId, currentSystem.currentOutputKW]);

  useEffect(() => {
    // Subtle real-world solar fluctuation (clouds, irradiance shift)
    const interval = setInterval(() => {
      setLiveKW((prev) => {
        const delta = (Math.random() - 0.48) * 0.15;
        const newKW = Math.max(0.5, Math.min(currentSystem.capacityKW * 0.95, prev + delta));
        return Math.round(newKW * 100) / 100;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [currentSystem.capacityKW]);

  const handleDownloadReport = () => {
    setShowDownloadFeedback(true);
    setTimeout(() => setShowDownloadFeedback(false), 3000);
  };

  const capacityRatio = Math.round((liveKW / currentSystem.capacityKW) * 100);

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/90 backdrop-blur-xl p-6 lg:p-8 shadow-2xl">
      {/* Header & System Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase mb-2">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            Live Client Performance & Service Telemetry
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Solar Asset Monitoring & History
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Real-time inverter production, Karachi dust degradation tracking, and verified maintenance logs.
          </p>
        </div>

        {/* System Switcher */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Select Monitored Site:</span>
          <div className="flex flex-wrap gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {DEMO_SYSTEMS.map((sys) => (
              <button
                key={sys.id}
                onClick={() => setSelectedSystemId(sys.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedSystemId === sys.id
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {sys.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Site Overview Strip */}
      <div className="mt-6 p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <Sun className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">{currentSystem.name}</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {currentSystem.systemType}
              </span>
            </div>
            <p className="text-xs text-slate-400">{currentSystem.location} • Client: {currentSystem.clientName}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onRequestWash(currentSystem)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Book De-ionized Wash
          </button>
          <button
            onClick={() => onRequestEmergency(currentSystem)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-colors"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Request SOS Tech
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 mt-6 gap-2">
        <button
          onClick={() => setActiveTab('realtime')}
          className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold transition-colors border-b-2 ${
            activeTab === 'realtime'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Gauge className="w-4 h-4" />
          Real-Time Metrics & Gauges
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold transition-colors border-b-2 ${
            activeTab === 'history'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-4 h-4" />
          Service & Cleaning History ({currentSystem.history.length})
        </button>
        <button
          onClick={() => setActiveTab('dust_comparison')}
          className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold transition-colors border-b-2 ${
            activeTab === 'dust_comparison'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Eye className="w-4 h-4" />
          Before & After Soiling Inspection
        </button>
      </div>

      {/* Tab 1: Real-Time Metrics */}
      {activeTab === 'realtime' && (
        <div className="mt-6 space-y-6">
          {/* Top Live Counters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Metric 1: Live Generation */}
            <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Current Power Output</span>
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-white font-mono">{liveKW}</span>
                <span className="text-sm font-bold text-amber-400">kW</span>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
                <span>Capacity: {currentSystem.capacityKW} kW</span>
                <span className="text-emerald-400 font-semibold">{capacityRatio}% Peak</span>
              </div>
              {/* Progress bar */}
              <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, capacityRatio)}%` }}
                />
              </div>
            </div>

            {/* Metric 2: Daily Yield */}
            <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Today's Generation</span>
                <Zap className="w-4 h-4 text-amber-400" />
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-white font-mono">
                  {currentSystem.dailyYieldKWh}
                </span>
                <span className="text-sm font-bold text-slate-400">kWh</span>
              </div>
              <p className="text-xs text-slate-500 mt-3">
                Saved today: <strong className="text-emerald-400">PKR {Math.round(currentSystem.dailyYieldKWh * 54).toLocaleString()}</strong>
              </p>
            </div>

            {/* Metric 3: Karachi Dust Soiling Loss */}
            <div className={`p-5 rounded-2xl border ${
              currentSystem.dustSoilingLossPercent > 20
                ? 'bg-rose-950/20 border-rose-800/60'
                : 'bg-slate-950/70 border-slate-800'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Dust Soiling Degradation</span>
                <Wind className="w-4 h-4 text-sky-400" />
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className={`text-3xl font-extrabold font-mono ${
                  currentSystem.dustSoilingLossPercent > 20 ? 'text-rose-400' : 'text-amber-400'
                }`}>
                  -{currentSystem.dustSoilingLossPercent}%
                </span>
                <span className="text-xs font-semibold text-slate-400">loss</span>
              </div>
              <p className="text-xs text-slate-400 mt-3">
                Cleaned: <strong className="text-slate-200">{currentSystem.lastCleanedDate}</strong>
              </p>
            </div>

            {/* Metric 4: Inverter Health Score */}
            <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Inverter Health Score</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-emerald-400 font-mono">
                  {currentSystem.inverterHealthScore}
                </span>
                <span className="text-sm font-bold text-slate-400">/ 100</span>
              </div>
              <p className="text-xs text-slate-500 mt-3 truncate">
                {currentSystem.inverterModel}
              </p>
            </div>
          </div>

          {/* Deep Inverter Telemetry Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Electrical Telemetry Box */}
            <div className="lg:col-span-8 bg-slate-950/50 p-6 rounded-2xl border border-slate-800">
              <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Live Inverter & String Telemetry (Karachi Grid Sync)
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[11px] text-slate-400">Grid Voltage</p>
                  <p className="text-lg font-bold text-white font-mono mt-1">
                    {currentSystem.gridVoltage} V
                  </p>
                  <p className="text-[10px] text-emerald-400">K-Electric Stable</p>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[11px] text-slate-400">Grid Frequency</p>
                  <p className="text-lg font-bold text-white font-mono mt-1">
                    {currentSystem.gridFrequency} Hz
                  </p>
                  <p className="text-[10px] text-slate-400">Nominal 50.0 Hz</p>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[11px] text-slate-400">MPPT 1 String</p>
                  <p className="text-lg font-bold text-amber-400 font-mono mt-1">
                    {currentSystem.mppt1Volts} V
                  </p>
                  <p className="text-[10px] text-slate-400">String balanced</p>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[11px] text-slate-400">Internal Temp</p>
                  <p className="text-lg font-bold text-sky-400 font-mono mt-1 flex items-center justify-center gap-1">
                    <Thermometer className="w-4 h-4" />
                    {currentSystem.inverterTempC}°C
                  </p>
                  <p className="text-[10px] text-emerald-400">Optimal cooling</p>
                </div>
              </div>

              {/* Monthly Financial Counter */}
              <div className="mt-5 p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs text-slate-400">Cumulative K-Electric Offset This Month</p>
                  <p className="text-xl font-extrabold text-emerald-400 font-mono">
                    PKR {currentSystem.monthlySavingsPKR.toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Next Scheduled Wash:</span>
                  <p className="text-xs font-bold text-amber-400">{currentSystem.nextRecommendedCleanDate}</p>
                </div>
              </div>
            </div>

            {/* Environmental & Dust Advisory */}
            <div className="lg:col-span-4 bg-slate-950/50 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <Sun className="w-4 h-4 text-amber-400" />
                  Karachi Atmospheric Impact
                </h4>
                <div className="space-y-3 text-xs text-slate-300">
                  <div className="flex justify-between pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Karachi Coastal Zone:</span>
                    <span className="font-semibold text-white">{currentSystem.zone}</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Airborne Salt & PM2.5:</span>
                    <span className="font-semibold text-amber-400">High (DHA / Coastal)</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Panels Installed:</span>
                    <span className="font-semibold text-white">{currentSystem.panelsCount} Tier-1 Panels</span>
                  </div>
                  {currentSystem.batterySOC && (
                    <div className="flex justify-between pb-2 border-b border-slate-800">
                      <span className="text-slate-400">Battery Reserve:</span>
                      <span className="font-semibold text-emerald-400">{currentSystem.batterySOC}% Charged</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-800/80">
                <button
                  onClick={() => onRequestWash(currentSystem)}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <Sparkles className="w-4 h-4" />
                  Restore +{currentSystem.dustSoilingLossPercent}% Output Now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Service History */}
      {activeTab === 'history' && (
        <div className="mt-6 space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <History className="w-4 h-4 text-amber-400" />
              Verified Technician Service Logs & Efficiency Gains
            </h4>

            <button
              onClick={handleDownloadReport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              {showDownloadFeedback ? 'Downloaded Signed Audit PDF!' : 'Download Complete Audit Log (PDF)'}
            </button>
          </div>

          <div className="space-y-4">
            {currentSystem.history.map((record) => (
              <div
                key={record.id}
                className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 hover:border-slate-700 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                      ✓
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-white">{record.type}</h5>
                      <p className="text-xs text-slate-400">
                        Technician: <span className="text-slate-300 font-medium">{record.technicianName}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" />
                      {record.date}
                    </span>
                    <span className="text-xs px-2.5 py-1 rounded-full font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                      +{Math.round((record.efficiencyAfter - record.efficiencyBefore) * 10) / 10}% Boost
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  {record.notes}
                </p>

                {/* Efficiency Before & After Visual Bar */}
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-800/60">
                  <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-400">Efficiency Before Wash:</span>
                    <span className="text-xs font-bold text-rose-400 font-mono">
                      {record.efficiencyBefore}%
                    </span>
                  </div>
                  <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-400">Efficiency After Wash:</span>
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      {record.efficiencyAfter}% (100% Restored)
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Before & After Soiling Inspection */}
      {activeTab === 'dust_comparison' && (
        <div className="mt-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                Karachi Dust & Soiling Analysis: Interactive Inspection Slider
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Drag the divider horizontally to view the extreme difference between a dust-choked panel and de-ionized cleaned glass.
              </p>
            </div>
            <span className="text-xs text-amber-400 font-medium px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30">
              Photographed on-site in DHA Karachi
            </span>
          </div>

          {/* Interactive Comparison Container */}
          <div className="relative h-80 sm:h-96 w-full rounded-2xl overflow-hidden border border-slate-700 select-none bg-slate-950">
            {/* Cleaned Panel (Right Side Background) */}
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{
                backgroundImage: `url('https://images.unsplash.com/photo-1508873696983-2df5293cb395?w=1200&auto=format&fit=crop&q=80')`
              }}
            >
              <div className="absolute top-4 right-4 bg-emerald-950/80 backdrop-blur-md text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-xl text-xs font-bold shadow-lg">
                ✨ After: 100% Spotless De-ionized Wash (98.4% Yield)
              </div>
            </div>

            {/* Dusty Panel (Left Side Clipped) */}
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{
                backgroundImage: `url('https://images.unsplash.com/photo-1509391365360-2e959784a276?w=1200&auto=format&fit=crop&q=80')`,
                clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)`
              }}
            >
              <div className="absolute top-4 left-4 bg-slate-950/80 backdrop-blur-md text-amber-400 border border-amber-500/40 px-3 py-1.5 rounded-xl text-xs font-bold shadow-lg">
                ⚠️ Before: Karachi Salt & Silt Crust (-28% Yield)
              </div>
            </div>

            {/* Slider Divider Line */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize flex items-center justify-center shadow-[0_0_15px_rgba(255,255,255,0.7)]"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="w-8 h-8 -ml-3.5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-xl border-2 border-white text-xs font-black">
                ↔
              </div>
            </div>

            {/* Invisible Range Input for Dragging */}
            <input
              type="range"
              min="0"
              max="100"
              value={sliderPosition}
              onChange={(e) => setSliderPosition(Number(e.target.value))}
              className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-300">
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <strong className="text-white block mb-1">Zero Water Scratches</strong>
              We use motorized soft horsehair rollers that never micro-abrade photovoltaic anti-reflective coatings.
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <strong className="text-white block mb-1">Zero Calcium Streaks</strong>
              Ordinary tap water in Karachi contains 600–1200 TDS. We purify our water to 0 TDS through 4-stage mobile reverse osmosis.
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <strong className="text-white block mb-1">Anti-Static Treatment</strong>
              Our final rinse includes an organic anti-static nano-layer that repels desert dust settling for up to 30 days.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
