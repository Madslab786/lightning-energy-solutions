import React from 'react';
import { 
  Sun, 
  Sparkles, 
  AlertTriangle, 
  Calculator, 
  Activity, 
  Bell, 
  Layers, 
  PhoneCall, 
  ShieldAlert,
  Menu,
  X
} from 'lucide-react';

interface NavbarProps {
  onOpenEmergency: () => void;
  onOpenWhatsApp: () => void;
  onOpenExport: () => void;
  onNavigate: (sectionId: string) => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenEmergency,
  onOpenWhatsApp,
  onOpenExport,
  onNavigate,
  activeSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState<boolean>(false);

  const navItems = [
    { id: 'services', label: 'Services & Pricing' },
    { id: 'calculator', label: 'Savings Calculator' },
    { id: 'dashboard', label: 'Client Performance' },
    { id: 'alerts', label: 'Scheduled Alerts' },
    { id: 'crm', label: 'Meta CRM Dispatch' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80">
      {/* Top micro-bar with Karachi Solar Weather */}
      <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 py-1.5 px-4 text-xs border-b border-slate-800/60 hidden sm:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-slate-300">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-amber-400 font-semibold">
              <Sun className="w-3.5 h-3.5 animate-spin [animation-duration:12s]" />
              Karachi Live Solar Index: 31°C • UV 8 (High Peak) • 5.9 kWh/m² Irradiance
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400">
              Dust Condition: Coastal Marine Silt • De-ionized Wash Recommended
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <a 
              href="https://www.facebook.com/share/18i1okkFZ9/" 
              target="_blank" 
              rel="noreferrer"
              className="text-slate-400 hover:text-blue-400 font-semibold transition-colors flex items-center gap-1"
            >
              <span>Facebook</span>
            </a>
            <span className="text-slate-700">•</span>
            <a 
              href="https://www.instagram.com/lightning_energy_solutions?srtk=Nm8wZHJiZzZxMnFp" 
              target="_blank" 
              rel="noreferrer"
              className="text-slate-400 hover:text-pink-400 font-semibold transition-colors flex items-center gap-1"
            >
              <span>Instagram</span>
            </a>
            <span className="text-slate-700">•</span>
            <a 
              href="https://wa.me/923122443449" 
              target="_blank" 
              rel="noreferrer" 
              className="text-amber-400 hover:underline font-mono font-bold flex items-center gap-1"
            >
              📲 +92 312 2443449
            </a>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand */}
        <div 
          onClick={() => handleNavClick('hero')} 
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-amber-500 to-yellow-300 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/30 group-hover:scale-105 transition-transform text-xl">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
                Lightning <span className="text-amber-400">Energy Solutions</span>
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-semibold tracking-wider flex items-center gap-1">
              <span className="text-amber-400">⚡</span> One-Window Solar Solution • Karachi
            </p>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeSection === item.id
                  ? 'bg-slate-800 text-amber-400 shadow-inner'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Action CTAs */}
        <div className="hidden sm:flex items-center gap-2">
          {/* Download Zip / Free Live Guide */}
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all shadow-sm cursor-pointer"
            title="Download full project folder & free deployment guide"
          >
            <span>📦 Download ZIP</span>
          </button>

          {/* Direct WhatsApp Callout */}
          <a
            href="https://wa.me/923122443449"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-emerald-500/40 text-xs font-bold transition-all"
            title="Chat directly on WhatsApp"
          >
            <span>💬</span>
            <span className="font-mono text-[11px]">+92 312 2443449</span>
          </a>

          {/* Emergency SOS Button */}
          <button
            onClick={onOpenEmergency}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 active:scale-95 animate-pulse"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>SOS (45m)</span>
          </button>

          {/* WhatsApp AI Button */}
          <button
            onClick={onOpenWhatsApp}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
          >
            <span>⚡ AI Guide</span>
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="lg:hidden flex items-center gap-2">
          <button
            onClick={onOpenEmergency}
            className="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold flex items-center gap-1"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            SOS
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-4 pt-2 pb-6 bg-slate-950 border-b border-slate-800 space-y-2 animate-in slide-in-from-top-3">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className="block w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-300 hover:bg-slate-900 hover:text-amber-400"
            >
              {item.label}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenEmergency();
              }}
              className="w-full py-3 rounded-xl bg-rose-600 text-white font-bold text-xs flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              Request Emergency Technician Visit
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenWhatsApp();
              }}
              className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2"
            >
              <span>💬</span> Connect with WhatsApp AI Assistant
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenExport();
              }}
              className="w-full py-2.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center justify-center gap-2"
            >
              <span>📦</span> Download Project Folder (ZIP) & Free Live Guide
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
