import React from 'react';
import { 
  Sun, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldCheck, 
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface FooterProps {
  onOpenEmergency: () => void;
  onOpenWhatsApp: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenEmergency,
  onOpenWhatsApp,
  onNavigate
}) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Column 1: Brand & Identity */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 text-xl">
                ⚡
              </div>
              <div>
                <span className="text-lg font-black text-white tracking-tight uppercase">
                  Lightning <span className="text-amber-400">Energy Solutions</span>
                </span>
                <p className="text-[10px] text-amber-400 font-semibold tracking-wide">
                  One-Window Solar Solution
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed pr-6">
              Professional solar services for residential & commercial customers in Karachi. 
              One-window solution covering specialized 0-TDS panel cleaning, rapid troubleshooting, preventive maintenance contracts, and turnkey installation.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a 
                href="https://www.facebook.com/share/18i1okkFZ9/" 
                target="_blank" 
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-blue-950/60 border border-blue-600/40 text-blue-300 font-semibold text-xs hover:bg-blue-900/60 transition-colors flex items-center gap-1.5"
              >
                <span>📘 Facebook Page</span>
              </a>
              <a 
                href="https://www.instagram.com/lightning_energy_solutions?srtk=Nm8wZHJiZzZxMnFp" 
                target="_blank" 
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-pink-950/60 border border-pink-600/40 text-pink-300 font-semibold text-xs hover:bg-pink-900/60 transition-colors flex items-center gap-1.5"
              >
                <span>📸 Instagram</span>
              </a>
            </div>
          </div>

          {/* Column 2: 4 Core Pillars */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              One-Window Services
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  1️⃣ Solar Panel Cleaning
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  2️⃣ Troubleshooting & Repair
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  3️⃣ Preventative Maintenance
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-amber-400 transition-colors text-left"
                >
                  4️⃣ Turnkey Solar Installation
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('calculator')}
                  className="hover:text-amber-400 transition-colors text-left text-emerald-400"
                >
                  ⚡ K-Electric ROI Calculator
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Karachi Areas */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Karachi Coverage
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li>• DHA (Phases 1 to 8)</li>
              <li>• Clifton (Blocks 1 to 9)</li>
              <li>• Gulshan-e-Iqbal & Johar</li>
              <li>• Bahria Town Karachi (M-9)</li>
              <li>• Korangi Industrial Area</li>
              <li>• SITE Industrial Area</li>
              <li>• PECHS, Nazimabad & Malir</li>
            </ul>
          </div>

          {/* Column 4: Contact & Assessment */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Karachi Head Office
            </h4>
            <div className="space-y-2 text-slate-300">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Karachi, Sindh, Pakistan</span>
              </p>
              <p className="flex items-center gap-2">
                <span className="text-emerald-400">📲</span>
                <a 
                  href="https://wa.me/923122443449" 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:underline font-mono font-bold text-white"
                >
                  +92 312 2443449
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400 shrink-0" />
                <span>Field Service: Mon–Sun (24/7 Troubleshooting Hotline)</span>
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <a
                href="https://wa.me/923122443449?text=Assalam-o-Alaikum%20Lightning%20Energy%20Solutions!%20I%20would%20like%20to%20request%20an%20assessment%20and%20quotation."
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors text-center shadow-lg"
              >
                💬 Message on WhatsApp
              </a>

              <button
                onClick={onOpenEmergency}
                className="w-full py-2 px-3 rounded-xl bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 border border-rose-500/40 text-[11px] font-bold transition-colors text-center"
              >
                🚨 Emergency Troubleshooting (45m)
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Credits */}
        <div className="mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <p>© {new Date().getFullYear()} ⚡ Lightning Energy Solutions. One-Window Solar Solution Karachi.</p>
          <div className="flex items-center gap-4">
            <a href="https://www.facebook.com/share/18i1okkFZ9/" target="_blank" rel="noreferrer" className="hover:text-blue-400">Facebook</a>
            <span>•</span>
            <a href="https://www.instagram.com/lightning_energy_solutions?srtk=Nm8wZHJiZzZxMnFp" target="_blank" rel="noreferrer" className="hover:text-pink-400">Instagram</a>
            <span>•</span>
            <a href="https://wa.me/923122443449" target="_blank" rel="noreferrer" className="hover:text-emerald-400 font-mono">+92 312 2443449</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
