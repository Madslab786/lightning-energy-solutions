import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Zap, 
  TrendingUp, 
  Sparkles, 
  Clock, 
  DollarSign, 
  Leaf, 
  ShieldCheck, 
  ArrowRight,
  AlertTriangle,
  Info
} from 'lucide-react';
import { KARACHI_AREAS } from '../data/solarData';

interface SavingsCalculatorProps {
  onBookWithSpecs: (specs: {
    systemKW: number;
    monthlyBillPKR: number;
    area: string;
    dustLossPercent: number;
    monthlySavingsPKR: number;
  }) => void;
  onOpenWhatsAppWithSpecs: (specsText: string) => void;
}

export const SavingsCalculator: React.FC<SavingsCalculatorProps> = ({
  onBookWithSpecs,
  onOpenWhatsAppWithSpecs
}) => {
  const [monthlyBillPKR, setMonthlyBillPKR] = useState<number>(75000);
  const [systemSizeKW, setSystemSizeKW] = useState<number>(10);
  const [selectedAreaId, setSelectedAreaId] = useState<string>('dha-khi');
  const [daysWithoutWash, setDaysWithoutWash] = useState<number>(25);
  const [hasNetMetering, setHasNetMetering] = useState<boolean>(true);

  const selectedArea = useMemo(() => {
    return KARACHI_AREAS.find((a) => a.id === selectedAreaId) || KARACHI_AREAS[0];
  }, [selectedAreaId]);

  // Karachi K-Electric Tariff Math & Soiling Model
  // NEPRA base off-peak ~42 PKR/unit, peak ~62 PKR/unit. Average effective unit cost with surcharges & fuel adjustments: ~PKR 54/kWh.
  // Karachi daily peak sun hours: ~5.1 peak sun hours/day.
  const calculations = useMemo(() => {
    const effectiveTariffPKR = 54;
    const netMeteringExportRatePKR = 24;

    // Ideal monthly generation (kWh) for system size in Karachi climate
    const idealMonthlyGenKWh = systemSizeKW * 5.1 * 30; // e.g. 10 * 5.1 * 30 = 1,530 kWh

    // Dust soiling penalty calculation in Karachi
    // Base soiling rate per 10 days for this Karachi zone
    const soilingPercent = Math.min(38, Math.round((daysWithoutWash / 10) * selectedArea.avgSoilingRate * 10) / 10);
    
    // Actual generation after Karachi dust loss
    const actualMonthlyGenKWh = Math.round(idealMonthlyGenKWh * (1 - soilingPercent / 100));
    const lostKWhDueToDust = idealMonthlyGenKWh - actualMonthlyGenKWh;

    // Financial calculations
    const estimatedCleanMonthlySavingsPKR = Math.round(idealMonthlyGenKWh * effectiveTariffPKR);
    const actualMonthlySavingsPKR = Math.round(actualMonthlyGenKWh * effectiveTariffPKR);
    const lostMoneyDueToDustPKR = estimatedCleanMonthlySavingsPKR - actualMonthlySavingsPKR;

    // Net bill reduction %
    const estimatedNewBillPKR = Math.max(0, monthlyBillPKR - actualMonthlySavingsPKR);
    const billReductionPercent = Math.min(95, Math.round((actualMonthlySavingsPKR / monthlyBillPKR) * 100));

    // Estimated system installation cost (Tier-1 Bloomberg Topcon panels + Hybrid Inverter in Pakistan approx PKR 110,000 - 130,000 per kW)
    const estimatedSystemCostPKR = systemSizeKW * 120000;
    const annualSavingsPKR = actualMonthlySavingsPKR * 12;
    const paybackYears = Math.round((estimatedSystemCostPKR / Math.max(1, annualSavingsPKR)) * 10) / 10;

    // Environmental offsets
    const co2AvoidedTonnes = Math.round((idealMonthlyGenKWh * 12 * 0.0007) * 10) / 10;
    const treesEquivalent = Math.round(co2AvoidedTonnes * 16);

    return {
      idealMonthlyGenKWh,
      actualMonthlyGenKWh,
      soilingPercent,
      lostKWhDueToDust,
      estimatedCleanMonthlySavingsPKR,
      actualMonthlySavingsPKR,
      lostMoneyDueToDustPKR,
      estimatedNewBillPKR,
      billReductionPercent,
      estimatedSystemCostPKR,
      paybackYears,
      co2AvoidedTonnes,
      treesEquivalent
    };
  }, [monthlyBillPKR, systemSizeKW, selectedArea, daysWithoutWash, hasNetMetering]);

  const handleBookNow = () => {
    onBookWithSpecs({
      systemKW: systemSizeKW,
      monthlyBillPKR,
      area: selectedArea.name,
      dustLossPercent: calculations.soilingPercent,
      monthlySavingsPKR: calculations.actualMonthlySavingsPKR
    });
  };

  const handleWhatsAppInquiry = () => {
    const text = `Assalam-o-Alaikum Lightning Energy Solutions! I used your Savings Calculator for my system in ${selectedArea.name}:\n` +
      `• System Size: ${systemSizeKW} kW\n` +
      `• Monthly K-Electric Bill: PKR ${monthlyBillPKR.toLocaleString()}\n` +
      `• Days without washing: ${daysWithoutWash} days (Estimated Dust Loss: -${calculations.soilingPercent}%)\n` +
      `• Potential Recoverable Savings: PKR ${calculations.lostMoneyDueToDustPKR.toLocaleString()}/mo\n` +
      `Please provide an assessment and quotation for cleaning & maintenance!`;
    onOpenWhatsAppWithSpecs(text);
  };

  return (
    <div className="relative overflow-hidden rounded-3xl border border-amber-500/20 bg-slate-900/90 backdrop-blur-xl p-6 lg:p-10 shadow-2xl shadow-amber-950/20">
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold tracking-wide uppercase mb-2">
            <Calculator className="w-3.5 h-3.5" />
            Karachi Solar & K-Electric ROI Engine
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Calculate Potential Energy Savings & Wash Recovery
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Grounded in current NEPRA / K-Electric tariffs and Karachi's specific dust & coastal humidity soiling rates.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700 text-xs">
          <span className="text-slate-400 px-2 font-medium">Net Metering:</span>
          <button
            onClick={() => setHasNetMetering(true)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              hasNetMetering
                ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Enabled (Export)
          </button>
          <button
            onClick={() => setHasNetMetering(false)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              !hasNetMetering
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Self-Use Only
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Controls Column */}
        <div className="lg:col-span-6 space-y-6">
          {/* Monthly Bill Input */}
          <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                Current Monthly K-Electric Bill
              </label>
              <span className="text-lg font-bold text-emerald-400 font-mono">
                PKR {monthlyBillPKR.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min="15000"
              max="500000"
              step="5000"
              value={monthlyBillPKR}
              onChange={(e) => setMonthlyBillPKR(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            {/* Quick Bill Presets */}
            <div className="flex flex-wrap gap-2 mt-3">
              {[35000, 75000, 150000, 300000].map((preset) => (
                <button
                  key={preset}
                  onClick={() => setMonthlyBillPKR(preset)}
                  className={`px-2.5 py-1 text-xs rounded-lg transition-colors border ${
                    monthlyBillPKR === preset
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  PKR {(preset / 1000)}k
                </button>
              ))}
            </div>
          </div>

          {/* System Size Input */}
          <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                System Capacity (Current or Planned)
              </label>
              <span className="text-lg font-bold text-amber-400 font-mono">
                {systemSizeKW} kW
                <span className="text-xs text-slate-400 font-normal ml-1.5">
                  (~{Math.round(systemSizeKW * 1.8)} panels)
                </span>
              </span>
            </div>
            <input
              type="range"
              min="3"
              max="100"
              step="1"
              value={systemSizeKW}
              onChange={(e) => setSystemSizeKW(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex flex-wrap gap-2 mt-3">
              {[5, 10, 15, 25, 50].map((kw) => (
                <button
                  key={kw}
                  onClick={() => setSystemSizeKW(kw)}
                  className={`px-2.5 py-1 text-xs rounded-lg transition-colors border ${
                    systemSizeKW === kw
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  {kw} kW
                </button>
              ))}
            </div>
          </div>

          {/* Karachi Location Selector */}
          <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-200">
                Karachi Location & Atmosphere
              </label>
              <span className="text-xs text-amber-400 font-medium">
                Soiling Rate: {selectedArea.avgSoilingRate}% / 10 days
              </span>
            </div>
            <select
              value={selectedAreaId}
              onChange={(e) => setSelectedAreaId(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
            >
              {KARACHI_AREAS.map((area) => (
                <option key={area.id} value={area.id}>
                  {area.name} — {area.zone} Karachi (Dust rate: {area.avgSoilingRate}%)
                </option>
              ))}
            </select>
            <p className="text-xs text-slate-500 mt-2 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              Industrial & highway zones (Korangi, SITE, M-9) accumulate cementitious soot faster than coastal zones.
            </p>
          </div>

          {/* Days Without Cleaning */}
          <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400" />
                Days Since Last Solar Panel Wash
              </label>
              <span className={`text-base font-bold font-mono ${
                daysWithoutWash > 20 ? 'text-rose-400' : 'text-sky-400'
              }`}>
                {daysWithoutWash} Days
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="60"
              step="1"
              value={daysWithoutWash}
              onChange={(e) => setDaysWithoutWash(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
            />
            {daysWithoutWash >= 20 && (
              <div className="mt-3 flex items-start gap-2 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/50 p-2.5 rounded-xl">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>
                  <strong>Critical Soiling Alert:</strong> Panels unwashed for 20+ days in Karachi develop baked-on salt-silica crust, reducing power generation by up to <strong>{calculations.soilingPercent}%</strong>.
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Results & Value Realization Column */}
        <div className="lg:col-span-6 space-y-5">
          {/* Main Savings Highlights */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 relative shadow-xl">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Monthly Projected Savings (Karachi K-Electric)
            </h3>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400 font-medium">Monthly Bill Reduction</p>
                <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono mt-1">
                  PKR {calculations.actualMonthlySavingsPKR.toLocaleString()}
                </p>
                <p className="text-xs text-emerald-500/80 mt-1 font-semibold">
                  ~{calculations.billReductionPercent}% of your electricity bill eliminated
                </p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400 font-medium">Estimated New Net Bill</p>
                <p className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-1">
                  PKR {calculations.estimatedNewBillPKR.toLocaleString()}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Down from PKR {monthlyBillPKR.toLocaleString()}
                </p>
              </div>
            </div>

            {/* De-ionized Clean Recovery Value Card */}
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3.5 mb-6">
              <div className="p-2.5 rounded-lg bg-amber-500/20 text-amber-400 shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-amber-300">
                    Recoverable Power from Clean Wash
                  </h4>
                  <span className="text-xs font-bold text-amber-400 font-mono bg-amber-500/20 px-2 py-0.5 rounded">
                    +{calculations.soilingPercent}% Output
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  You are currently losing approximately <strong>PKR {calculations.lostMoneyDueToDustPKR.toLocaleString()}</strong> every month ({calculations.lostKWhDueToDust} kWh) due to Karachi dust crust.
                  A single de-ionized wash instantly restores this output!
                </p>
              </div>
            </div>

            {/* Key Metrics Breakdown */}
            <div className="grid grid-cols-3 gap-3 text-center border-t border-slate-800/80 pt-4">
              <div className="p-2.5 rounded-xl bg-slate-950/50">
                <p className="text-[11px] text-slate-400">Monthly Yield</p>
                <p className="text-base font-bold text-white font-mono mt-0.5">
                  {calculations.actualMonthlyGenKWh} kWh
                </p>
                <p className="text-[10px] text-slate-500">
                  Ideal: {calculations.idealMonthlyGenKWh}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/50">
                <p className="text-[11px] text-slate-400">Payback Period</p>
                <p className="text-base font-bold text-emerald-400 font-mono mt-0.5">
                  {calculations.paybackYears} Years
                </p>
                <p className="text-[10px] text-slate-500">Rapid ROI</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/50">
                <p className="text-[11px] text-slate-400">CO2 Offset</p>
                <p className="text-base font-bold text-sky-400 font-mono mt-0.5">
                  {calculations.co2AvoidedTonnes} T/yr
                </p>
                <p className="text-[10px] text-slate-500">🌱 {calculations.treesEquivalent} trees</p>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={handleBookNow}
              className="flex items-center justify-center gap-2 px-5 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl transition-all shadow-lg shadow-amber-500/20 active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4" />
              Book Cleaning / Audit
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={handleWhatsAppInquiry}
              className="flex items-center justify-center gap-2 px-5 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-emerald-600/20 active:scale-[0.98]"
            >
              <span className="text-lg">💬</span>
              WhatsApp AI Instant Quote
            </button>
          </div>

          <div className="flex items-center justify-center gap-4 text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> 100% Scratch-Free Guarantee
            </span>
            <span>•</span>
            <span>0-TDS Purified RO Wash</span>
            <span>•</span>
            <span>All Karachi Neighborhoods</span>
          </div>
        </div>
      </div>
    </div>
  );
};
