import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  CreditCard,
  User,
  Phone
} from 'lucide-react';
import { KARACHI_AREAS, SOLAR_SERVICES } from '../data/solarData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialServiceId?: string;
  initialSpecs?: {
    systemKW: number;
    monthlyBillPKR: number;
    area: string;
    dustLossPercent: number;
    monthlySavingsPKR: number;
  };
  onBookingSuccess?: (ticket: any) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialServiceId,
  initialSpecs,
  onBookingSuccess
}) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    initialServiceId || SOLAR_SERVICES[0].id
  );
  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [selectedArea, setSelectedArea] = useState<string>(
    initialSpecs?.area || KARACHI_AREAS[0].name
  );
  const [address, setAddress] = useState<string>('');
  const [date, setDate] = useState<string>('Tomorrow');
  const [timeSlot, setTimeSlot] = useState<string>('09:00 AM – 11:30 AM (Cool Morning Slot)');
  const [systemSizeKW, setSystemSizeKW] = useState<number>(
    initialSpecs?.systemKW || 10
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [bookedTicket, setBookedTicket] = useState<any>(null);

  if (!isOpen) return null;

  const currentService =
    SOLAR_SERVICES.find((s) => s.id === selectedServiceId) || SOLAR_SERVICES[0];

  // Base price calculation in PKR based on system size
  const calculatedPricePKR = Math.max(
    currentService.priceStartingPKR,
    Math.round(currentService.priceStartingPKR * (systemSizeKW / 10))
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const newTicket = {
      source: 'web_booking',
      customerName: customerName || 'Booked Client',
      phone: phone || '+92 300 0000000',
      area: `${selectedArea}${address ? ' - ' + address : ''}`,
      systemSize: `${systemSizeKW} kW Array`,
      inverterBrand: 'Residential / Commercial Inverter',
      serviceType: currentService.name,
      urgency: 'NORMAL',
      description: `Scheduled Booking for ${date} (${timeSlot}). System: ${systemSizeKW}kW. Price: PKR ${calculatedPricePKR.toLocaleString()}. Address: ${address}`,
      technicianNotes: `Prepare de-ionized 0-TDS water mobile tank, rotary nylon brushes, and string multimeters for ${selectedArea}.`,
      status: 'PENDING',
    };

    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTicket),
      });
      const data = await res.json();
      setBookedTicket(data.ticket || newTicket);
      if (onBookingSuccess) onBookingSuccess(data.ticket || newTicket);
      setIsSuccess(true);
    } catch {
      setBookedTicket(newTicket);
      setIsSuccess(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border border-amber-500/30 p-6 sm:p-8 shadow-2xl max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSuccess ? (
          <div>
            <div className="mb-6">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 uppercase tracking-wide">
                Karachi Service Reservation
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white mt-2">
                Book Solar Service & Maintenance
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Zero-scratch de-ionized cleaning, repair, or system audits delivered to your doorstep.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Service Selection */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Select Solar Service
                </label>
                <select
                  value={selectedServiceId}
                  onChange={(e) => setSelectedServiceId(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                >
                  {SOLAR_SERVICES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} (from PKR {s.priceStartingPKR.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              {/* System Size */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-semibold text-slate-300">System Capacity (kW)</span>
                  <span className="text-sm font-bold text-amber-400 font-mono">{systemSizeKW} kW</span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="60"
                  step="1"
                  value={systemSizeKW}
                  onChange={(e) => setSystemSizeKW(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Personal Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Asad Mehmood"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    WhatsApp Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 0300 2489110"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Area & Address */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Karachi Area *
                  </label>
                  <select
                    value={selectedArea}
                    onChange={(e) => setSelectedArea(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                  >
                    {KARACHI_AREAS.map((a) => (
                      <option key={a.id} value={a.name}>
                        {a.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    House / Street Address
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. Plot 15-C, Street 8"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Date & Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Preferred Date
                  </label>
                  <select
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                  >
                    <option value="Tomorrow">Tomorrow</option>
                    <option value="In 2 Days">In 2 Days</option>
                    <option value="This Weekend (Saturday)">This Weekend (Saturday)</option>
                    <option value="This Weekend (Sunday)">This Weekend (Sunday)</option>
                    <option value="Next Week">Next Week</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Time Slot
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-amber-400 focus:outline-none"
                  >
                    <option value="08:30 AM – 10:30 AM (Cool Morning Slot - Best)">08:30 AM – 10:30 AM (Cool Morning)</option>
                    <option value="11:00 AM – 01:00 PM (Midday Slot)">11:00 AM – 01:00 PM (Midday)</option>
                    <option value="04:30 PM – 06:30 PM (Evening Sunset Slot)">04:30 PM – 06:30 PM (Evening Sunset)</option>
                  </select>
                </div>
              </div>

              {/* Price Estimate Card */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Estimated Price:</span>
                  <p className="text-xl font-extrabold text-amber-400 font-mono">
                    PKR {calculatedPricePKR.toLocaleString()}
                  </p>
                  <span className="text-[10px] text-slate-500">Includes 0-TDS water & full electrical audit</span>
                </div>
                <div className="text-right text-xs text-emerald-400 font-medium">
                  ✓ Pay After Service via Cash / Raast / Bank
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl transition-all shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
              >
                <Sparkles className="w-5 h-5" />
                {isSubmitting ? 'Confirming Reservation...' : 'Confirm Karachi Booking'}
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-6 space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
                Booking Confirmed
              </span>
              <h3 className="text-2xl font-black text-white mt-2">
                Technician Slot Reserved
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Booking Reference: <strong className="text-amber-400 font-mono">{bookedTicket?.id || 'TK-KHI-8910'}</strong>
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-left text-xs space-y-2">
              <div className="flex justify-between pb-1 border-b border-slate-800">
                <span className="text-slate-400">Service:</span>
                <span className="font-bold text-white">{currentService.name}</span>
              </div>
              <div className="flex justify-between pb-1 border-b border-slate-800">
                <span className="text-slate-400">Date & Slot:</span>
                <span className="font-bold text-amber-300">{date} • {timeSlot}</span>
              </div>
              <div className="flex justify-between pb-1 border-b border-slate-800">
                <span className="text-slate-400">Karachi Area:</span>
                <span className="font-bold text-white">{selectedArea}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Total:</span>
                <span className="font-bold text-emerald-400 font-mono">PKR {calculatedPricePKR.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors"
            >
              Done & Return to Dashboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
