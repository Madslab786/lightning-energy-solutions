import React, { useState } from 'react';
import { 
  X, 
  AlertTriangle, 
  PhoneCall, 
  MapPin, 
  Zap, 
  Clock, 
  ShieldAlert, 
  CheckCircle, 
  Navigation, 
  User, 
  Truck,
  ExternalLink,
  Phone
} from 'lucide-react';
import { KARACHI_AREAS } from '../data/solarData';

interface EmergencySOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSystemName?: string;
  onTicketCreated?: (ticket: any) => void;
}

export const EmergencySOSModal: React.FC<EmergencySOSModalProps> = ({
  isOpen,
  onClose,
  initialSystemName,
  onTicketCreated
}) => {
  const [step, setStep] = useState<'form' | 'dispatched'>('form');
  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [selectedArea, setSelectedArea] = useState<string>('DHA (Phases 1-8)');
  const [streetAddress, setStreetAddress] = useState<string>('');
  const [faultType, setFaultType] = useState<string>('Inverter Shutdown / Fault Code Error');
  const [inverterBrand, setInverterBrand] = useState<string>('Inverex Nitrox');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [ticketDetails, setTicketDetails] = useState<any>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const payload = {
      source: 'emergency_sos',
      customerName: customerName || 'Emergency Caller',
      phone: phone || '+92 300 0000000',
      area: `${selectedArea}${streetAddress ? ' - ' + streetAddress : ''}`,
      systemSize: 'Urgent System Callout',
      inverterBrand: inverterBrand,
      serviceType: 'Emergency Inverter Repair',
      urgency: 'EMERGENCY',
      description: `URGENT BREAKDOWN: ${faultType} on ${inverterBrand}. Street: ${streetAddress}`,
      technicianNotes: `Emergency SOS callout. Lead engineer dispatched with mobile testing oscilloscope and DC surge protectors. Priority <45 min.`,
      assignedTechnician: 'Senior Engr. Tariq Mehmood (Rapid SOS Van #1)',
      status: 'EN_ROUTE',
      etaMinutes: 34
    };

    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      setTicketDetails(data.ticket || payload);
      if (onTicketCreated) onTicketCreated(data.ticket || payload);
      setStep('dispatched');
    } catch {
      setTicketDetails(payload);
      setStep('dispatched');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsAppEmergency = () => {
    const text = encodeURIComponent(
      `🚨 EMERGENCY SOLAR TROUBLESHOOTING - KARACHI\n` +
      `⚡ LIGHTNING ENERGY SOLUTIONS DISPATCH\n` +
      `• Name: ${customerName || 'Urgent Customer'}\n` +
      `• Phone: ${phone}\n` +
      `• Area: ${selectedArea} (${streetAddress})\n` +
      `• Inverter: ${inverterBrand}\n` +
      `• Issue: ${faultType}\n` +
      `Please dispatch the nearest mobile technician immediately!`
    );
    window.open(`https://wa.me/923122443449?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border border-rose-500/40 p-6 sm:p-8 shadow-2xl shadow-rose-950/50 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'form' ? (
          <div>
            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse text-xl font-black">
                ⚡
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    Emergency Troubleshooting SOS
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white uppercase tracking-wider">
                    45m Arrival
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Lightning Energy Solutions: Rapid mobile technician dispatch across all Karachi zones.
                </p>
              </div>
            </div>

            {/* Emergency Hotline Alert */}
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-800/60 mb-6 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <PhoneCall className="w-5 h-5 text-rose-400 animate-bounce" />
                <div>
                  <p className="text-xs font-semibold text-rose-200">24/7 Karachi Hotline:</p>
                  <a href="tel:+923122443449" className="text-base font-black text-white hover:underline font-mono">
                    +92 312 2443449
                  </a>
                </div>
              </div>
              <button
                type="button"
                onClick={handleWhatsAppEmergency}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <span>💬</span> WhatsApp SOS
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Select Urgent Issue Type *
                </label>
                <select
                  value={faultType}
                  onChange={(e) => setFaultType(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none"
                >
                  <option value="Inverter Shutdown / Fault Code Error">Inverter Complete Shutdown / Fault Code (F08, F01, etc.)</option>
                  <option value="Smoke, Sparking or Burning Smell from DB / Inverter">Smoke, Sparking or Burning Smell (High Hazard)</option>
                  <option value="Zero Power Generation during Peak Sunshine">Zero Power Generation During Peak Sunshine</option>
                  <option value="Cracked Solar Glass / Physical Panel Storm Damage">Cracked Solar Glass / Storm / Structure Damage</option>
                  <option value="K-Electric Net Meter Islanding Trip Failure">K-Electric Net Meter Islanding Trip Failure</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Tariq Siddiqui"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    WhatsApp / Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 0300 1234567"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Karachi Neighborhood *
                  </label>
                  <select
                    value={selectedArea}
                    onChange={(e) => setSelectedArea(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none"
                  >
                    {KARACHI_AREAS.map((a) => (
                      <option key={a.id} value={a.name}>
                        {a.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Inverter Brand / Model
                  </label>
                  <select
                    value={inverterBrand}
                    onChange={(e) => setInverterBrand(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none"
                  >
                    <option value="Inverex (Nitrox / Aerox / Yukon)">Inverex (Nitrox / Aerox / Yukon)</option>
                    <option value="Huawei Sun2000">Huawei Sun2000</option>
                    <option value="Knox Krypton / Xenon">Knox Krypton / Xenon</option>
                    <option value="Growatt / GoodWe / Solis">Growatt / GoodWe / Solis</option>
                    <option value="Fronius / Sungrow">Fronius / Sungrow</option>
                    <option value="Other / Not Sure">Other / Not Sure</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Street Address / House No. (Karachi)
                </label>
                <input
                  type="text"
                  value={streetAddress}
                  onChange={(e) => setStreetAddress(e.target.value)}
                  placeholder="e.g. House 42-B, Street 14, Phase 6"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 px-6 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-black rounded-xl transition-all shadow-xl shadow-rose-600/30 flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
                >
                  <Truck className="w-5 h-5" />
                  {isSubmitting ? 'Dispatching Emergency Van...' : 'DISPATCH EMERGENCY TECHNICIAN NOW'}
                </button>
                <p className="text-[11px] text-center text-slate-400 mt-2">
                  ⚡ Mobile unit dispatched from nearest hub (DHA, Shahrah-e-Faisal or Korangi Expressway).
                </p>
              </div>
            </form>
          </div>
        ) : (
          /* Step 2: Live Dispatch Confirmation & Real-time ETA Tracker */
          <div className="text-center py-2 space-y-6">
            <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/50 flex items-center justify-center mx-auto animate-pulse">
              <Truck className="w-8 h-8" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase tracking-wider">
                🚨 Mobile SOS Van Dispatched
              </span>
              <h3 className="text-2xl font-black text-white mt-2">
                Technician Is En Route
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Ticket ID: <span className="font-mono text-amber-400 font-bold">{ticketDetails?.id || 'TK-KHI-8992'}</span>
              </p>
            </div>

            {/* ETA Card */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-left space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Clock className="w-4 h-4 text-amber-400" />
                  Estimated Arrival Time:
                </div>
                <span className="text-xl font-extrabold text-amber-400 font-mono">
                  ~30 - 40 Mins
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">
                  <User className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <p className="text-xs text-slate-400">Assigned Lead Engineer:</p>
                  <p className="text-sm font-bold text-white">Senior Engr. Tariq Mehmood</p>
                  <p className="text-[11px] text-emerald-400">Certified Inverter Diagnostics Specialist</p>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                <Navigation className="w-4 h-4 text-sky-400 shrink-0" />
                <span>
                  Mobile Van #1 en route via <strong>Shahrah-e-Faisal / Khayaban-e-Ittehad</strong>
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="tel:+923122443449"
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-slate-700"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                Call Driver / Engineer (+92 312 2443449)
              </a>

              <button
                onClick={handleWhatsAppEmergency}
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                <span>💬</span> Track on WhatsApp
              </button>
            </div>

            <button
              onClick={onClose}
              className="text-xs text-slate-400 hover:text-white underline"
            >
              Close this window (Ticket remains active in our technician dispatch system)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
