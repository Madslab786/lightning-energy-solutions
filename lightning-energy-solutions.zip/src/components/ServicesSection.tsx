import React from 'react';
import { 
  Check, 
  Sparkles, 
  ShieldAlert, 
  Activity, 
  ShieldCheck, 
  Clock, 
  ArrowRight,
  Zap,
  Building2,
  Home,
  Cpu
} from 'lucide-react';
import { SOLAR_SERVICES } from '../data/solarData';

interface ServicesSectionProps {
  onSelectService: (serviceId: string) => void;
  onOpenEmergency: () => void;
  onOpenWhatsApp: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectService,
  onOpenEmergency,
  onOpenWhatsApp
}) => {
  return (
    <section className="py-16 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="px-3.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 uppercase tracking-wider">
            ⚡ LIGHTNING ENERGY SOLUTIONS • KARACHI
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-3">
            One-Window Solar Solution
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-2">
            Professional solar services for residential & commercial customers in Karachi. 
            From pure 0-TDS panel cleaning to 45-minute troubleshooting and turnkey installations.
          </p>
          <div className="mt-4 flex justify-center">
            <a
              href="https://wa.me/923122443449?text=Assalam-o-Alaikum%20Lightning%20Energy%20Solutions!%20I%20would%20like%20to%20request%20an%20assessment%20and%20quotation%20in%20Karachi."
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-lg"
            >
              <span>📲 Contact us for assessment & quotation on WhatsApp: 0312 2443449</span>
            </a>
          </div>
        </div>

        {/* 4 Core Maintenance Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SOLAR_SERVICES.map((service) => {
            const isEmergency = service.id === 'troubleshooting';
            const isPopular = service.id === 'solar-cleaning';

            return (
              <div
                key={service.id}
                className={`flex flex-col justify-between rounded-3xl p-6 border transition-all duration-300 relative ${
                  isEmergency
                    ? 'bg-rose-950/20 border-rose-500/40 hover:border-rose-400 shadow-xl shadow-rose-950/30'
                    : isPopular
                    ? 'bg-amber-950/15 border-amber-500/50 hover:border-amber-400 shadow-xl shadow-amber-950/20'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                {service.badge && (
                  <div className="absolute -top-3 left-6">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-md ${
                      isEmergency
                        ? 'bg-rose-600 text-white'
                        : 'bg-amber-500 text-slate-950'
                    }`}>
                      {service.badge}
                    </span>
                  </div>
                )}

                <div>
                  <div className="mt-2">
                    <h3 className="text-lg font-bold text-white tracking-tight">
                      {service.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 min-h-[32px] leading-relaxed">
                      {service.tagline}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="mt-5 pb-5 border-b border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Starting from</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-2xl font-black text-white font-mono">
                        PKR {service.priceStartingPKR.toLocaleString()}
                      </span>
                      <span className="text-xs text-slate-400 font-normal">/ visit</span>
                    </div>
                    <span className="text-[11px] text-amber-400 font-semibold block mt-1">
                      ⏱ Duration: {service.duration}
                    </span>
                  </div>

                  {/* Features */}
                  <div className="mt-5 space-y-2.5">
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                      What's Included:
                    </span>
                    {service.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer CTA */}
                <div className="mt-6 pt-4 border-t border-slate-800/80">
                  <p className="text-[11px] text-slate-500 mb-3 italic">
                    {service.recommendedInterval}
                  </p>
                  {isEmergency ? (
                    <button
                      onClick={onOpenEmergency}
                      className="w-full py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <ShieldAlert className="w-4 h-4" />
                      Request SOS Dispatch (45m)
                    </button>
                  ) : (
                    <button
                      onClick={() => onSelectService(service.id)}
                      className={`w-full py-3 px-4 rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95 ${
                        isPopular
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          : 'bg-slate-800 hover:bg-slate-700 text-white'
                      }`}
                    >
                      <Sparkles className="w-4 h-4" />
                      Book This Service
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Turnkey Solar Projects & Installations Section */}
        <div className="mt-16 rounded-3xl bg-slate-900/60 border border-slate-800 p-8 sm:p-10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 uppercase">
                Turnkey Engineering & EPC
              </span>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
                New Solar Installations & Performance Projects
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
                Looking to install a new high-efficiency solar power plant in Karachi? 
                We manage everything from K-Electric net metering documentation to Tier-1 N-Type TOPCon panels and cloud monitoring.
              </p>
            </div>

            <button
              onClick={onOpenWhatsApp}
              className="px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg flex items-center gap-2 self-start lg:self-center shrink-0"
            >
              <span>💬</span> Get Custom EPC Project Quote
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold mb-4">
                  <Home className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white">Residential Net-Metered Systems</h4>
                <p className="text-xs text-slate-400 mt-1">5 kW, 10 kW, 15 kW Rooftop Solar</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  Engineered for DHA, Clifton, Bahria Town and PECHS villas. Includes K-Electric green meter documentation and 25-year panel degradation warranty.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-semibold">
                <span>Save up to 90% on electricity</span>
                <span>ROI: ~2.8 Yrs</span>
              </div>
            </div>

            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold mb-4">
                  <Building2 className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white">Commercial & Industrial EPC</h4>
                <p className="text-xs text-slate-400 mt-1">50 kW to 500 kW+ Factory Arrays</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  Tailored for Korangi, SITE, and Port Qasim industrial units. Heavy-duty structural engineering rated for 140 km/h coastal wind gusts and automated wash piping.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-sky-400 font-semibold">
                <span>Slash B3/B4 tariff peak units</span>
                <span>ROI: ~2.2 Yrs</span>
              </div>
            </div>

            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-4">
                  <Cpu className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white">Hybrid + LiFePO4 Energy Storage</h4>
                <p className="text-xs text-slate-400 mt-1">Zero-Loadshedding Battery Backup</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  Seamless 10-millisecond UPS failover using Dyness or Pylontech Lithium iron phosphate storage. Keeps inverters online through any Karachi grid blackout.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-semibold">
                <span>6,000+ Cycles (15 Yr Life)</span>
                <span>24/7 Power Security</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
