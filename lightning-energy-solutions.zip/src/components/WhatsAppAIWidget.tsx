import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  CheckCheck, 
  Phone, 
  Video, 
  MoreVertical, 
  Paperclip, 
  Smile, 
  ExternalLink, 
  Bot, 
  User, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Layers, 
  Maximize2, 
  Minimize2,
  FileSpreadsheet
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}

interface TechnicianTriageData {
  hasTriageData?: boolean;
  ticketId?: string;
  customerName?: string;
  phone?: string;
  area?: string;
  floor?: string;
  systemSize?: string;
  waterOnSite?: string;
  electricSupply?: string;
  walkwayAccess?: string;
  inverterBrand?: string;
  serviceType?: string;
  urgency?: 'EMERGENCY' | 'HIGH' | 'NORMAL';
  technicianNotes?: string;
}

interface WhatsAppAIWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
  initialPrompt?: string;
  onTicketDispatched?: (ticket: any) => void;
}

export const WhatsAppAIWidget: React.FC<WhatsAppAIWidgetProps> = ({
  isOpen,
  onClose,
  onOpen,
  initialPrompt,
  onTicketDispatched
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'model',
      content: 'Assalam-o-Alaikum! ⚡ Welcome to Lightning Energy Solutions — One-Window Solar Solution in Karachi.\n\nProfessional solar services for residential & commercial customers:\n1️⃣ Solar Panel Cleaning (0-TDS de-ionized)\n2️⃣ Troubleshooting (Rapid inverter & fault repair)\n3️⃣ Maintenance (Preventative checks & audits)\n4️⃣ Installation (Turnkey On-Grid & Hybrid)\n\nWhich area in Karachi is your system located, and what service can we assist you with today?',
      timestamp: 'Just now'
    }
  ]);
  const [inputVal, setInputVal] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [activeTriageData, setActiveTriageData] = useState<TechnicianTriageData | null>(null);
  const [showTriageDrawer, setShowTriageDrawer] = useState<boolean>(false);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [metaSyncNotice, setMetaSyncNotice] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      sendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  const sendMessage = async (textToSend?: string) => {
    const text = textToSend || inputVal.trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/gemini/whatsapp-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role,
            content: m.content
          })),
          userProfile: {
            name: 'WhatsApp Web User',
            phone: '+92 312 2443449'
          }
        })
      });

      const data = await response.json();

      if (data.reply) {
        const botMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          role: 'model',
          content: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, botMsg]);
      }

      if (data.triageData && data.triageData.hasTriageData !== false) {
        setActiveTriageData(data.triageData);
        setShowTriageDrawer(true);
        if (onTicketDispatched && data.triageData.ticketId) {
          onTicketDispatched(data.triageData);
        }
      }
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        content: 'JazakAllah for reaching out to Lightning Energy Solutions! Our Karachi team has received your message. You can also chat directly on WhatsApp at +92 312 2443449.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleLaunchWhatsAppDirect = () => {
    const defaultText = activeTriageData
      ? `⚡ LIGHTNING ENERGY SOLUTIONS — INQUIRY SUMMARY\n` +
        `📍 Karachi Client Request\n\n` +
        `• Service: ${activeTriageData.serviceType || 'One-Window Solar Service'}\n` +
        `• Customer: ${activeTriageData.customerName || 'Client'}\n` +
        `• Area / Location: ${activeTriageData.area || 'Karachi'}\n` +
        `• Floor / Height: ${activeTriageData.floor || 'Rooftop'}\n` +
        `• System Capacity: ${activeTriageData.systemSize || 'Residential/Commercial'}\n` +
        `• Water on Site: ${activeTriageData.waterOnSite || 'To be verified'}\n` +
        `• Electric Supply: ${activeTriageData.electricSupply || 'Available'}\n` +
        `• Walkway / Roof Access: ${activeTriageData.walkwayAccess || 'Standard access'}\n` +
        `• Inverter / Details: ${activeTriageData.inverterBrand || 'Standard'}\n` +
        `• Priority: ${activeTriageData.urgency || 'Normal'}\n\n` +
        `💬 Technical Notes: ${activeTriageData.technicianNotes || 'Inquiry captured via AI Concierge'}\n\n` +
        `Please confirm assessment & technician quotation.`
      : `Assalam-o-Alaikum ⚡ Lightning Energy Solutions! I am interested in assessment & quotation for my solar system in Karachi.\n\nServices Needed:\n1️⃣ Solar Panel Cleaning\n2️⃣ Troubleshooting\n3️⃣ Maintenance\n4️⃣ Installation`;

    const encoded = encodeURIComponent(defaultText);
    window.open(`https://wa.me/923122443449?text=${encoded}`, '_blank');
  };

  const handlePushToMetaBusinessSuite = () => {
    setMetaSyncNotice('Synced to Lightning Energy Solutions Dispatch Queue!');
    setTimeout(() => setMetaSyncNotice(null), 3500);
  };

  const quickPrompts = [
    '1️⃣ Solar Panel Cleaning Quote',
    '2️⃣ Urgent Troubleshooting (Inverter Trip)',
    '3️⃣ Maintenance & Preventative Audit',
    '4️⃣ Turnkey Installation Assessment',
    '📍 DHA / Clifton / Bahria Town Service',
  ];

  return (
    <>
      {/* Floating Action WhatsApp Bubble */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-5">
          <div className="hidden sm:flex flex-col items-end bg-slate-900/95 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-emerald-500/30 text-xs shadow-xl">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
              ⚡ WhatsApp AI Guide
            </span>
            <span className="text-[11px] text-emerald-400 font-medium">Lightning Energy Solutions</span>
          </div>

          <a
            href="https://wa.me/923122443449"
            target="_blank"
            rel="noreferrer"
            onClick={(e) => {
              // Open modal on click or let user choose
              e.preventDefault();
              onOpen();
            }}
            className="group relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xl shadow-emerald-950/60 transition-all duration-300 hover:scale-105 active:scale-95"
            aria-label="Open WhatsApp AI Assistant"
          >
            <span className="text-2xl sm:text-3xl">💬</span>
            <span className="absolute -top-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500 text-[10px] font-bold text-slate-950 items-center justify-center">
                ⚡
              </span>
            </span>
          </a>
        </div>
      )}

      {/* WhatsApp Modal Simulator */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className={`relative flex flex-col rounded-3xl bg-slate-950 border border-emerald-500/30 shadow-2xl overflow-hidden transition-all duration-300 ${
              isFullScreen
                ? 'w-full h-full max-w-none max-h-none rounded-none'
                : 'w-full max-w-2xl h-[88vh] max-h-[750px]'
            }`}
          >
            {/* WhatsApp Green Top Header */}
            <div className="bg-emerald-800 px-4 py-3 text-white flex items-center justify-between shadow-md shrink-0">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-black text-lg shadow">
                    ⚡
                  </div>
                  <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-emerald-800" />
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-sm tracking-wide">⚡ Lightning Energy Solutions</h3>
                    <span className="text-[10px] bg-emerald-700/80 text-emerald-200 px-1.5 py-0.5 rounded font-semibold">
                      Verified Business
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-100 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span>
                    Online • One-Window Solar Solution • +92 312 2443449
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activeTriageData && (
                  <button
                    onClick={() => setShowTriageDrawer(!showTriageDrawer)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold transition-colors"
                    title="View Categorized Technician Card"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Technician Card</span>
                  </button>
                )}

                <button
                  onClick={() => setIsFullScreen(!isFullScreen)}
                  className="p-1.5 rounded-lg hover:bg-emerald-700 text-emerald-100 transition-colors hidden sm:block"
                  title="Toggle Fullscreen"
                >
                  {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>

                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg hover:bg-emerald-700 text-emerald-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sub-Banner: Meta Business Suite Bridge Info */}
            <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300 shrink-0">
              <span className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                <Bot className="w-3.5 h-3.5 text-emerald-400" />
                AI auto-extracts your location, inverter brand & issue into clean technician triage format.
              </span>
              <button
                onClick={handleLaunchWhatsAppDirect}
                className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 shrink-0"
              >
                <span>Open in App</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            {/* Categorized Technician Card Drawer (If AI extracted structured details) */}
            {activeTriageData && showTriageDrawer && (
              <div className="bg-slate-900/95 border-b border-amber-500/30 p-4 shrink-0 animate-in slide-in-from-top-2">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                      Categorized Technician Triage Card
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      activeTriageData.urgency === 'EMERGENCY'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300'
                    }`}>
                      Urgency: {activeTriageData.urgency || 'NORMAL'}
                    </span>
                  </div>
                  <button
                    onClick={() => setShowTriageDrawer(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Hide
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Customer & Area:</span>
                    <span className="font-semibold text-white truncate block">
                      {activeTriageData.customerName || 'Client'} ({activeTriageData.area || 'Karachi'})
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Service & Urgency:</span>
                    <span className="font-semibold text-emerald-400 truncate block">
                      {activeTriageData.serviceType}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Water & Electric:</span>
                    <span className="font-semibold text-sky-300 truncate block">
                      💧 {activeTriageData.waterOnSite || 'Yes'} • ⚡ {activeTriageData.electricSupply || 'Yes'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Floor & Walkway:</span>
                    <span className="font-semibold text-amber-300 truncate block">
                      🏢 {activeTriageData.floor || 'Rooftop'} • 🚶 {activeTriageData.walkwayAccess || 'Standard'}
                    </span>
                  </div>
                </div>

                {activeTriageData.technicianNotes && (
                  <p className="text-[11px] text-slate-300 mt-2 bg-slate-950/50 p-2.5 rounded-lg border border-slate-800 leading-relaxed">
                    🛠️ <strong>Technician Brief:</strong> {activeTriageData.technicianNotes}
                  </p>
                )}

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <button
                    onClick={handleLaunchWhatsAppDirect}
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-95"
                  >
                    <span>💬</span> Send Summary to My WhatsApp (+92 312 2443449)
                  </button>

                  <button
                    onClick={handlePushToMetaBusinessSuite}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
                  >
                    Save to CRM
                  </button>

                  {metaSyncNotice && (
                    <span className="text-[11px] text-emerald-400 animate-in fade-in w-full text-right">
                      ✓ {metaSyncNotice}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Chat Body (WhatsApp Pattern Wallpaper) */}
            <div 
              className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/95"
              style={{
                backgroundImage: `radial-gradient(#1e293b 1px, transparent 1px)`,
                backgroundSize: '24px 24px'
              }}
            >
              {/* Encrypted Disclaimer */}
              <div className="flex justify-center my-2">
                <span className="px-3 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px] text-slate-400 text-center max-w-sm">
                  🔒 Messages are processed in real-time by SolarCare Karachi's Meta Business Suite AI and dispatched directly to local Karachi technicians.
                </span>
              </div>

              {messages.map((m) => {
                const isBot = m.role === 'model';
                return (
                  <div
                    key={m.id}
                    className={`flex ${isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`relative max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 shadow-md ${
                        isBot
                          ? 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-sm'
                          : 'bg-emerald-700 text-white rounded-tr-sm'
                      }`}
                    >
                      <p className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                        {m.content}
                      </p>
                      <div
                        className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${
                          isBot ? 'text-slate-500' : 'text-emerald-200'
                        }`}
                      >
                        <span>{m.timestamp}</span>
                        {!isBot && <CheckCheck className="w-3.5 h-3.5 text-sky-300" />}
                      </div>
                    </div>
                  </div>
                );
              })}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-slate-900 border border-slate-800 text-slate-400 rounded-2xl rounded-tl-sm px-4 py-2.5 text-xs flex items-center gap-1.5 shadow">
                    <span className="flex space-x-1">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce"></span>
                    </span>
                    <span className="text-[11px] text-slate-400 ml-1">SolarBot is typing...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Prompts Bar */}
            <div className="p-2 bg-slate-900/90 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
              {quickPrompts.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => sendMessage(q)}
                  className="whitespace-nowrap px-3 py-1 rounded-full bg-slate-950 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white text-[11px] transition-colors shrink-0"
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 shrink-0">
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="Ask about Karachi solar cleaning, inverter repair, or prices..."
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500 placeholder:text-slate-500"
              />

              <button
                onClick={() => sendMessage()}
                disabled={!inputVal.trim() || isTyping}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-40 disabled:hover:bg-emerald-600 shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
