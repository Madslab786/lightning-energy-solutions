import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Github, 
  Globe, 
  CheckCircle2, 
  Copy, 
  ExternalLink, 
  FolderArchive, 
  Sparkles, 
  ArrowRight,
  Zap,
  MessageCircle,
  HelpCircle
} from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'download' | 'github' | 'vercel' | 'whatsapp'>('download');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleCopyDownload = () => {
    const url = window.location.origin + '/download-zip';
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-bold text-xl">
              📦
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Website Folder Download & Free GitHub/Vercel Guide
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/40">
                  100% Free
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Puri website ka folder yahan se download karein aur bina kisi kharchay k live karein
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 px-6 gap-2 pt-2">
          <button
            onClick={() => setActiveTab('download')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'download'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            1. Folder Download (ZIP)
          </button>

          <button
            onClick={() => setActiveTab('github')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'github'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Github className="w-4 h-4" />
            2. GitHub Upload (Easy)
          </button>

          <button
            onClick={() => setActiveTab('vercel')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'vercel'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            3. Vercel Free Live (0 PKR)
          </button>

          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'whatsapp'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            4. WhatsApp AI Setup
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm flex-1">
          {activeTab === 'download' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-amber-500/10 via-slate-800/40 to-slate-900 border border-amber-500/30 rounded-xl p-5 text-center">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center text-3xl mb-3 shadow-lg shadow-amber-500/20">
                  📁
                </div>
                <h4 className="text-base font-bold text-white mb-1">
                  Lightning Energy Solutions - Complete Project Folder (.ZIP)
                </h4>
                <p className="text-xs text-slate-300 max-w-md mx-auto mb-4">
                  Aap k paas computer ya mobile me folder nahi tha, is liye hum ne aap ka pura project aik clean ZIP file me band kar k tayar kar diya hai!
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                  <a
                    href="/download-zip"
                    download="lightning-energy-solutions.zip"
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/30 transition-all active:scale-95 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Project ZIP Abhi Karein (62 KB)</span>
                  </a>

                  <button
                    onClick={handleCopyDownload}
                    className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                  >
                    {copiedLink ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedLink ? 'Link Copied!' : 'Copy Direct Link'}</span>
                  </button>
                </div>
              </div>

              {/* Instructions in Roman Urdu */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3">
                <h5 className="font-bold text-amber-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  Download k baad kya karna hai? (Easy 2 Steps):
                </h5>
                <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>
                    <strong className="text-white">ZIP File Download karein:</strong> Upar diye gaye yellow button par click karein. Aap k device me <code className="text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded">lightning-energy-solutions.zip</code> save ho jayegi.
                  </li>
                  <li>
                    <strong className="text-white">Extract / Unzip karein:</strong> Apne computer ya laptop me downloaded ZIP file par right-click karein aur <strong className="text-amber-300">"Extract All"</strong> ya <strong className="text-amber-300">"Extract Here"</strong> par click karein.
                  </li>
                  <li>
                    Aap k samnay ek folder ban kar aa jayega jisme sari files (<code className="text-slate-400">package.json, src, index.html, vercel.json</code>) mojood hongi!
                  </li>
                </ol>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => setActiveTab('github')}
                  className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 hover:text-amber-300 hover:underline"
                >
                  <span>Agla Step: GitHub par bina code likhe kasy upload karein?</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {activeTab === 'github' && (
            <div className="space-y-4">
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4">
                <h4 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
                  <Github className="w-5 h-5 text-amber-400" />
                  GitHub par Baghair kisi Command ya Coding k Folder Upload Karein:
                </h4>
                <p className="text-xs text-slate-400 mb-3">
                  Aap ko koi complex Git command ya terminal use karne ki zaroorat nahi hai. GitHub ki website par seedha files drag & drop ho jati hain!
                </p>

                <div className="space-y-3 text-xs text-slate-300">
                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">1</span>
                    <div>
                      <p className="font-bold text-white">GitHub par Free Account banayein:</p>
                      <p className="text-slate-400">
                        <a href="https://github.com/signup" target="_blank" rel="noreferrer" className="text-amber-400 underline font-semibold inline-flex items-center gap-1">
                          github.com <ExternalLink className="w-3 h-3" />
                        </a> par jayein aur apna free account login karein.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">2</span>
                    <div>
                      <p className="font-bold text-white">Nayi Repository banayein:</p>
                      <p className="text-slate-400">
                        Top right par <strong className="text-white">+ (Plus)</strong> icon par click kar k <strong className="text-white">"New repository"</strong> select karein. Repository ka naam rakhein: <code className="text-amber-300 bg-slate-950 px-1 py-0.5 rounded">lightning-energy</code> aur neeche green button <strong className="text-white">"Create repository"</strong> click karein.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">3</span>
                    <div>
                      <p className="font-bold text-white">"uploading an existing file" par click karein:</p>
                      <p className="text-slate-400">
                        Screen par blue color ka link hoga: <em className="text-amber-300">"uploading an existing file"</em>. Us par click karein.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">4</span>
                    <div>
                      <p className="font-bold text-white">Drag & Drop karein:</p>
                      <p className="text-slate-400">
                        Jo ZIP file aap ne extract ki thi, us folder k andar mojood sari files ko mouse se pakar kar GitHub k box me drop kar dein. Sari files upload ho jayengi!
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">5</span>
                    <div>
                      <p className="font-bold text-white">Commit Changes par click karein:</p>
                      <p className="text-slate-400">
                        Neeche green button <strong className="text-emerald-400">"Commit changes"</strong> dabayein. Bas! Aap ka project GitHub par save ho gaya!
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => setActiveTab('vercel')}
                  className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 hover:text-amber-300 hover:underline"
                >
                  <span>Step 3: Vercel par 1-minute me Free Live kasy karein?</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {activeTab === 'vercel' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-emerald-500/10 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-xl p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xl">
                    ▲
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-white">Vercel.com Par 100% Free Live Setup</h4>
                    <p className="text-xs text-emerald-400 font-semibold">Kharcha: Rs 0 (Hamesha k liye bilkul free)</p>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Hum ne project me pehle se <code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">vercel.json</code> config file shamil kar di hai, is liye Vercel par aik click me build ho jaye ga!
                </p>

                <div className="space-y-2.5 text-xs text-slate-300">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5">
                    <span className="font-bold text-emerald-400 shrink-0">Step 1:</span>
                    <div>
                      <a href="https://vercel.com/signup" target="_blank" rel="noreferrer" className="text-amber-400 font-bold underline inline-flex items-center gap-1">
                        vercel.com <ExternalLink className="w-3 h-3" />
                      </a> par jayein aur <strong className="text-white">"Continue with GitHub"</strong> select karein.
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5">
                    <span className="font-bold text-emerald-400 shrink-0">Step 2:</span>
                    <div>
                      Dashboard par <strong className="text-white">"Add New" ➔ "Project"</strong> par click karein.
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5">
                    <span className="font-bold text-emerald-400 shrink-0">Step 3:</span>
                    <div>
                      Aap ko aap ki GitHub repository <code className="text-amber-300">lightning-energy</code> nazar aayegi. Us k samnay <strong className="text-emerald-400">"Import"</strong> button click karein.
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5">
                    <span className="font-bold text-emerald-400 shrink-0">Step 4:</span>
                    <div>
                      Neeche blue button <strong className="text-blue-400 font-bold">"Deploy"</strong> par click karein. 1 minute me website live ho jayegi aur aap ko aisa free official link mil jayega:
                      <p className="mt-1 font-mono text-emerald-300 bg-slate-950 px-2 py-1 rounded border border-emerald-500/30">
                        https://lightning-energy-solutions.vercel.app
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'whatsapp' && (
            <div className="space-y-4">
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-lg">
                    📲
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    WhatsApp Business AI Auto-Response (Friendly Conversational Triage)
                  </h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  Aap ka target: Jab b koi client aap k WhatsApp number <strong className="text-emerald-400">+92 312 2443449</strong> par message kare, to AI agent friendly andaaz me baat kare, queries hal kare, aur details collect kar k points me categorize kar k aap ko bhej de!
                </p>

                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <h5 className="font-bold text-amber-400 mb-1">
                      1. Solar Cleaning k liye AI kya poochta hai:
                    </h5>
                    <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                      <li>Water availability on site (pani ka tap/line mojood hai?)</li>
                      <li>Electric power supply (motor/washer k liye bijli connection?)</li>
                      <li>Safe roof walkway & access (chhat par jane ka rasta?)</li>
                      <li>Exact Karachi location / area</li>
                      <li>Floor level (Ground, 1st, 2nd, etc.)</li>
                      <li>System capacity in kW / panels count</li>
                    </ul>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <h5 className="font-bold text-amber-400 mb-1">
                      2. Baqi 3 Options (Troubleshooting, Maintenance, Installation):
                    </h5>
                    <p className="text-slate-300">
                      Website k andar AI Concierge aur Meta Business Suite CRM simulator me ye chaaron options bilkul active hain! Client ki Roman Urdu / English me baat sun kar sari details bullet points me save karta hai.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30">
                    <h5 className="font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
                      <Zap className="w-4 h-4" />
                      Free Live Testing:
                    </h5>
                    <p className="text-slate-300">
                      Website par right side par floating green button <strong className="text-emerald-400">"WhatsApp AI Guide"</strong> daba kar aap is AI conversation ka real experience abhi kar saktay hain!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Lightning Energy Solutions • Karachi
          </span>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
