import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Search, 
  Filter, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Truck, 
  User, 
  MapPin, 
  Phone, 
  ExternalLink, 
  ShieldAlert, 
  Sparkles, 
  RefreshCw,
  Zap,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { TechnicianTicket } from '../types';

export const MetaBusinessSuiteCRM: React.FC = () => {
  const [tickets, setTickets] = useState<TechnicianTicket[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [filterUrgency, setFilterUrgency] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchTickets = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/tickets');
      const data = await res.json();
      if (data.tickets) {
        setTickets(data.tickets);
      }
    } catch (e) {
      console.error('Failed to fetch tickets:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleUpdateStatus = async (ticketId: string, newStatus: TechnicianTicket['status']) => {
    setUpdatingId(ticketId);
    try {
      const res = await fetch(`/api/tickets/${ticketId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success && data.ticket) {
        setTickets((prev) =>
          prev.map((t) => (t.id === ticketId ? data.ticket : t))
        );
      }
    } catch (e) {
      console.error('Status update failed:', e);
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredTickets = tickets.filter((t) => {
    const matchesUrgency = filterUrgency === 'ALL' || t.urgency === filterUrgency;
    const matchesStatus = filterStatus === 'ALL' || t.status === filterStatus;
    const matchesSearch =
      searchQuery === '' ||
      t.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.inverterBrand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesUrgency && matchesStatus && matchesSearch;
  });

  const emergencyCount = tickets.filter((t) => t.urgency === 'EMERGENCY').length;
  const pendingCount = tickets.filter((t) => t.status === 'PENDING').length;

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/90 backdrop-blur-xl p-6 lg:p-8 shadow-2xl">
      {/* Meta Business Suite Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold uppercase">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
              Meta Business Suite • Lightning Energy Solutions Hub
            </span>
            <a 
              href="https://www.facebook.com/share/18i1okkFZ9/" 
              target="_blank" 
              rel="noreferrer"
              className="text-xs text-blue-400 hover:underline flex items-center gap-1 bg-blue-950/40 px-2.5 py-1 rounded-lg border border-blue-800/60"
            >
              📘 Open Facebook Page
            </a>
            <a 
              href="https://wa.me/923122443449" 
              target="_blank" 
              rel="noreferrer"
              className="text-xs text-emerald-400 hover:underline flex items-center gap-1 bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-800/60 font-mono"
            >
              📲 WhatsApp Business (+92 312 2443449)
            </a>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Categorized Technician Review & Live Dispatch
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Every customer WhatsApp AI conversation and emergency request is auto-sorted into a clean, categorized format for your technicians to review.
          </p>
        </div>

        {/* Live Counters */}
        <div className="flex items-center gap-3">
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center px-4">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Urgent SOS</span>
            <span className="text-lg font-black text-rose-400 font-mono">{emergencyCount}</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center px-4">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Pending Review</span>
            <span className="text-lg font-black text-amber-400 font-mono">{pendingCount}</span>
          </div>
          <button
            onClick={fetchTickets}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
            title="Refresh tickets"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by area, customer, inverter..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Urgency Filter */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400 px-2 text-[11px]">Priority:</span>
            {['ALL', 'EMERGENCY', 'HIGH', 'NORMAL'].map((urg) => (
              <button
                key={urg}
                onClick={() => setFilterUrgency(urg)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                  filterUrgency === urg
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {urg}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400 px-2 text-[11px]">Status:</span>
            {['ALL', 'PENDING', 'ASSIGNED', 'EN_ROUTE', 'RESOLVED'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                  filterStatus === st
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="mt-6 space-y-4">
        {filteredTickets.length === 0 ? (
          <div className="text-center py-12 bg-slate-950/40 rounded-2xl border border-slate-800 text-slate-400">
            <p className="text-sm">No tickets matching the selected filters.</p>
          </div>
        ) : (
          filteredTickets.map((ticket) => (
            <div
              key={ticket.id}
              className={`p-5 rounded-2xl border transition-all ${
                ticket.urgency === 'EMERGENCY'
                  ? 'bg-rose-950/20 border-rose-800/60 shadow-lg shadow-rose-950/20'
                  : ticket.urgency === 'HIGH'
                  ? 'bg-amber-950/15 border-amber-500/40'
                  : 'bg-slate-950/60 border-slate-800'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs font-bold text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                    {ticket.id}
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    ticket.urgency === 'EMERGENCY'
                      ? 'bg-rose-500 text-white animate-pulse'
                      : ticket.urgency === 'HIGH'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-300'
                  }`}>
                    {ticket.urgency}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1 font-semibold">
                    Source: {ticket.source === 'whatsapp_ai' ? '💬 WhatsApp AI' : '🚨 Urgent SOS'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Current Status:</span>
                  <select
                    value={ticket.status}
                    disabled={updatingId === ticket.id}
                    onChange={(e) => handleUpdateStatus(ticket.id, e.target.value as any)}
                    className="px-3 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs font-bold text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="PENDING">PENDING REVIEW</option>
                    <option value="ASSIGNED">TECHNICIAN ASSIGNED</option>
                    <option value="EN_ROUTE">EN ROUTE</option>
                    <option value="ON_SITE">ON SITE</option>
                    <option value="RESOLVED">RESOLVED</option>
                  </select>
                </div>
              </div>

              {/* Categorized Specifications Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs">
                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Client / Phone</span>
                  <p className="font-bold text-white truncate mt-0.5">{ticket.customerName}</p>
                  <a href={`tel:${ticket.phone}`} className="text-emerald-400 font-mono hover:underline text-[11px] block truncate">
                    {ticket.phone}
                  </a>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Karachi Location</span>
                  <p className="font-bold text-amber-300 truncate mt-0.5">{ticket.area}</p>
                  <span className="text-[10px] text-slate-400 block truncate">Route: Main Hub Dispatch</span>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">System & Inverter</span>
                  <p className="font-bold text-white truncate mt-0.5">{ticket.systemSize}</p>
                  <span className="text-slate-400 text-[11px] block truncate">{ticket.inverterBrand}</span>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Service Type</span>
                  <p className="font-bold text-emerald-300 truncate mt-0.5">{ticket.serviceType}</p>
                  {ticket.assignedTechnician ? (
                    <span className="text-slate-400 text-[10px] block truncate">Tech: {ticket.assignedTechnician}</span>
                  ) : (
                    <span className="text-rose-400 text-[10px] block font-semibold">Unassigned Van</span>
                  )}
                </div>
              </div>

              {/* User Description and Technician Brief */}
              <div className="mt-3.5 space-y-2">
                <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800/80 text-xs">
                  <span className="text-[11px] font-bold text-slate-400 block mb-1">Raw Client Request / Problem:</span>
                  <p className="text-slate-200 italic leading-relaxed">"{ticket.description}"</p>
                </div>

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-amber-300">AI Technician Briefing & Kit Recommendation:</span>
                    <p className="text-slate-300 mt-0.5 leading-relaxed">{ticket.technicianNotes}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Logged: {new Date(ticket.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  {ticket.etaMinutes && (
                    <span className="text-amber-400 font-semibold">• ETA to Site: ~{ticket.etaMinutes} mins</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/${ticket.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <span>💬</span> WhatsApp Client
                  </a>

                  <a
                    href={`tel:${ticket.phone}`}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-400" /> Call Directly
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
