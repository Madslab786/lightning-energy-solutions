/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { SavingsCalculator } from './components/SavingsCalculator';
import { PerformanceDashboard } from './components/PerformanceDashboard';
import { AutomatedAlertsSection } from './components/AutomatedAlertsSection';
import { MetaBusinessSuiteCRM } from './components/MetaBusinessSuiteCRM';
import { EmergencySOSModal } from './components/EmergencySOSModal';
import { BookingModal } from './components/BookingModal';
import { WhatsAppAIWidget } from './components/WhatsAppAIWidget';
import { ExportModal } from './components/ExportModal';
import { Footer } from './components/Footer';
import { DemoSolarSystem } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isBookingOpen, setIsBookingOpen] = useState<boolean>(false);
  const [whatsAppInitialPrompt, setWhatsAppInitialPrompt] = useState<string>('');
  const [bookingServiceId, setBookingServiceId] = useState<string>('solar-cleaning');
  const [bookingSpecs, setBookingSpecs] = useState<any>(null);

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenEmergency = () => {
    setIsEmergencyOpen(true);
  };

  const handleOpenWhatsAppWithPrompt = (promptText?: string) => {
    if (promptText) {
      setWhatsAppInitialPrompt(promptText);
    }
    setIsWhatsAppOpen(true);
  };

  const handleBookWithSpecs = (specs: any) => {
    setBookingSpecs(specs);
    setBookingServiceId('solar-cleaning');
    setIsBookingOpen(true);
  };

  const handleSelectService = (serviceId: string) => {
    setBookingServiceId(serviceId);
    setBookingSpecs(null);
    setIsBookingOpen(true);
  };

  const handleWashFromDashboard = (system: DemoSolarSystem) => {
    setBookingSpecs({
      systemKW: system.capacityKW,
      area: system.zone,
      monthlyBillPKR: system.monthlySavingsPKR,
      dustLossPercent: system.dustSoilingLossPercent,
      monthlySavingsPKR: system.monthlySavingsPKR
    });
    setBookingServiceId('solar-cleaning');
    setIsBookingOpen(true);
  };

  const handleEmergencyFromDashboard = (_system: DemoSolarSystem) => {
    setIsEmergencyOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Direct Download & Deployment Notification Bar */}
      <aside aria-label="Project Download Notification" className="bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-400 text-slate-950 px-4 py-2 text-xs sm:text-sm font-bold flex flex-wrap items-center justify-between gap-2 shadow-lg z-50">
        <div className="flex items-center gap-2">
          <span className="bg-slate-950 text-amber-300 px-2 py-0.5 rounded text-[11px] font-black uppercase tracking-wider">
            📁 Project Folder
          </span>
          <span className="font-extrabold text-slate-950">
            Aapka Website Code Folder (ZIP) Tayyar Hai! GitHub par upload karne ke liye yahan se download karein:
          </span>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="/download-zip"
            download="lightning-energy-solutions.zip"
            className="bg-slate-950 hover:bg-slate-900 text-amber-300 hover:text-amber-200 px-3 py-1 rounded-lg text-xs font-black shadow flex items-center gap-1.5 transition-all active:scale-95"
          >
            <span>📥 Download ZIP (Click Here)</span>
          </a>
          <button
            onClick={() => setIsExportOpen(true)}
            className="bg-slate-900/10 hover:bg-slate-900/20 text-slate-950 px-2.5 py-1 rounded-lg text-xs font-extrabold underline transition-all"
          >
            Roman Urdu Guide Dekhein
          </button>
        </div>
      </aside>

      {/* Top Navbar */}
      <Navbar
        onOpenEmergency={handleOpenEmergency}
        onOpenWhatsApp={() => handleOpenWhatsAppWithPrompt()}
        onOpenExport={() => setIsExportOpen(true)}
        onNavigate={handleNavigate}
        activeSection={activeSection}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <div id="hero">
          <HeroSection
            onOpenEmergency={handleOpenEmergency}
            onOpenWhatsApp={() => handleOpenWhatsAppWithPrompt()}
            onScrollToCalculator={() => handleNavigate('calculator')}
            onScrollToDashboard={() => handleNavigate('dashboard')}
            onOpenExport={() => setIsExportOpen(true)}
          />
        </div>

        {/* Services & Pricing Section */}
        <div id="services">
          <ServicesSection
            onSelectService={handleSelectService}
            onOpenEmergency={handleOpenEmergency}
            onOpenWhatsApp={() => handleOpenWhatsAppWithPrompt()}
          />
        </div>

        {/* Savings & ROI Calculator Section */}
        <section id="calculator" className="py-16 border-t border-slate-800/80 bg-slate-950/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SavingsCalculator
              onBookWithSpecs={handleBookWithSpecs}
              onOpenWhatsAppWithSpecs={handleOpenWhatsAppWithPrompt}
            />
          </div>
        </section>

        {/* Real-Time Client Performance Dashboard & Service History */}
        <section id="dashboard" className="py-16 border-t border-slate-800/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <PerformanceDashboard
              onRequestWash={handleWashFromDashboard}
              onRequestEmergency={handleEmergencyFromDashboard}
            />
          </div>
        </section>

        {/* Automated Notification System for Scheduled Maintenance Alerts */}
        <section id="alerts" className="py-16 border-t border-slate-800/80 bg-slate-950/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <AutomatedAlertsSection
              onScheduleCleaning={(_systemName) => handleSelectService('deionized-cleaning')}
              onRequestEmergency={handleOpenEmergency}
            />
          </div>
        </section>

        {/* Meta Business Suite & Categorized Technician Dispatch CRM */}
        <section id="crm" className="py-16 border-t border-slate-800/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <MetaBusinessSuiteCRM />
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer
        onOpenEmergency={handleOpenEmergency}
        onOpenWhatsApp={() => handleOpenWhatsAppWithPrompt()}
        onNavigate={handleNavigate}
      />

      {/* Emergency SOS Modal (One-click instant mobile technician dispatch) */}
      <EmergencySOSModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />

      {/* Standard Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        initialServiceId={bookingServiceId}
        initialSpecs={bookingSpecs}
      />

      {/* WhatsApp AI Concierge & Chat Simulator Widget */}
      <WhatsAppAIWidget
        isOpen={isWhatsAppOpen}
        onClose={() => setIsWhatsAppOpen(false)}
        onOpen={() => handleOpenWhatsAppWithPrompt()}
        initialPrompt={whatsAppInitialPrompt}
      />

      {/* Project Folder Download & Free Deployment Guide Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />
    </div>
  );
}
