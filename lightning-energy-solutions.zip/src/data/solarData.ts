import { KarachiArea, SolarService, DemoSolarSystem, ScheduledAlert } from '../types';

export const KARACHI_AREAS: KarachiArea[] = [
  { id: 'dha-khi', name: 'DHA (Phases 1-8)', zone: 'South', avgSoilingRate: 8.5 },
  { id: 'clifton-khi', name: 'Clifton (Blocks 1-9)', zone: 'South', avgSoilingRate: 8.2 },
  { id: 'gulshan-khi', name: 'Gulshan-e-Iqbal', zone: 'East', avgSoilingRate: 9.8 },
  { id: 'johar-khi', name: 'Gulistan-e-Johar', zone: 'East', avgSoilingRate: 9.4 },
  { id: 'pechs-khi', name: 'PECHS & Tariq Road', zone: 'East', avgSoilingRate: 9.1 },
  { id: 'north-naz-khi', name: 'North Nazimabad', zone: 'Central', avgSoilingRate: 10.2 },
  { id: 'fb-area-khi', name: 'Federal B Area', zone: 'Central', avgSoilingRate: 10.0 },
  { id: 'bahria-khi', name: 'Bahria Town Karachi (M-9)', zone: 'Malir', avgSoilingRate: 11.5 },
  { id: 'malir-cantt-khi', name: 'Malir Cantt & Model Colony', zone: 'Malir', avgSoilingRate: 8.9 },
  { id: 'korangi-ind-khi', name: 'Korangi Industrial Area', zone: 'Korangi', avgSoilingRate: 14.2 },
  { id: 'site-ind-khi', name: 'SITE Industrial Area', zone: 'West', avgSoilingRate: 14.8 },
  { id: 'port-qasim-khi', name: 'Port Qasim & Bin Qasim', zone: 'Malir', avgSoilingRate: 13.0 },
];

export const SOLAR_SERVICES: SolarService[] = [
  {
    id: 'solar-cleaning',
    name: '1️⃣ Solar Panel Cleaning (0-TDS Purified)',
    tagline: 'Spotless 0-TDS purified wash dissolving Karachi coastal salt, road grime & soot',
    priceStartingPKR: 4500,
    duration: '1.5 – 2.5 hours',
    bestFor: 'Residential & Commercial arrays needing 20% to 35% recovered power output',
    features: [
      'Pure 0-TDS de-mineralized water (Leaves zero chalky calcium streaks)',
      'Ultra-soft scratch-resistant rotary horsehair microfiber brushes',
      'Anti-static nano-sheen shield (slows future dust settling by 40%)',
      'Free Before & After DC current and voltage efficiency measurement',
      'Frame earthing & junction box integrity check'
    ],
    recommendedInterval: 'Every 21 to 30 days in Karachi',
    badge: '1️⃣ Solar Panel Cleaning'
  },
  {
    id: 'troubleshooting',
    name: '2️⃣ Troubleshooting & Emergency Repair',
    tagline: 'Urgent diagnostic & inverter fault repair within 45 minutes across Karachi',
    priceStartingPKR: 5500,
    duration: 'Within 45m arrival',
    bestFor: 'Inverter error trips (F08, Fault 01), smoke smell, cable burn, zero power production',
    features: [
      'Dedicated mobile SOS repair van dispatched with complete spare parts',
      'Licensed Inverter Diagnostics Engineer with thermal scanner & clamp meter',
      'DC Surge Protection Device (SPD) & MC4 terminal burn replacement',
      'String voltage balancing & ground fault detection',
      'Direct K-Electric grid tie synchronization diagnosis'
    ],
    recommendedInterval: 'Immediate as-needed troubleshooting',
    badge: '2️⃣ Troubleshooting (45m SOS)'
  },
  {
    id: 'maintenance',
    name: '3️⃣ Preventative Maintenance & Audits',
    tagline: 'Comprehensive system optimization, drone thermography & AMC coverage',
    priceStartingPKR: 8500,
    duration: '2.5 – 3.5 hours',
    bestFor: 'Annual health contracts, inverter filter servicing, and maximum efficiency',
    features: [
      'FLIR High-resolution Thermal IR Drone scan for invisible micro-cracks & cell hotspots',
      'Individual string Voc and Isc health assessment',
      'Inverter MPPT tracking efficiency and firmware tuning',
      'High-wind coastal torque check on mounting rails (up to 140 km/h gusts)',
      'Scheduled monthly cleaning alerts and signed engineering health reports'
    ],
    recommendedInterval: 'Bi-annually or Annual AMC',
    badge: '3️⃣ Maintenance'
  },
  {
    id: 'installation',
    name: '4️⃣ Turnkey Solar Installation',
    tagline: 'Complete On-Grid & Hybrid setups with K-Electric Net Metering support',
    priceStartingPKR: 45000,
    duration: '3 – 7 Days Delivery',
    bestFor: 'New residential villas, commercial buildings, and factories across Karachi',
    features: [
      'Tier-1 N-Type TOPCon bifacial high-efficiency panels',
      'Top-tier Hybrid / On-Grid Inverters (Huawei, Inverex, Knox, Growatt)',
      'High-grade galvanized aluminum structure rated for coastal weather',
      'Complete end-to-end K-Electric green meter documentation',
      'Real-time IoT cloud monitoring portal for lifetime yield tracking'
    ],
    recommendedInterval: 'One-time turnkey project with 25-yr panel warranty',
    badge: '4️⃣ Installation'
  }
];

export const DEMO_SYSTEMS: DemoSolarSystem[] = [
  {
    id: 'sys-dha',
    name: 'DHA Phase 6 Residence',
    clientName: 'Imran Farooq',
    location: 'Khayaban-e-Hafiz, DHA Phase 6, Karachi',
    zone: 'South Karachi',
    capacityKW: 12.5,
    panelsCount: 22,
    inverterModel: 'Huawei SUN2000-12KTL-M2 On-Grid',
    systemType: 'On-Grid',
    installationDate: 'March 2024',
    currentOutputKW: 9.8,
    dailyYieldKWh: 54.2,
    monthlySavingsPKR: 84500,
    dustSoilingLossPercent: 21.4,
    lastCleanedDate: '24 days ago (March 23)',
    nextRecommendedCleanDate: 'Overdue (Dust Alert active)',
    inverterHealthScore: 94,
    gridVoltage: 232.4,
    gridFrequency: 50.08,
    mppt1Volts: 485.2,
    mppt2Volts: 490.6,
    inverterTempC: 41.5,
    history: [
      {
        id: 'rec-1',
        date: '2026-03-23',
        type: 'EcoPure De-ionized Solar Wash',
        technicianName: 'Engr. Bilal Farooq & Crew',
        efficiencyBefore: 76.2,
        efficiencyAfter: 98.4,
        notes: 'Thick layer of coastal salt crust and exhaust carbon removed using 0-TDS water. Output jumped by 22.2%.',
        photoBeforeUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=600&auto=format&fit=crop&q=80',
        photoAfterUrl: 'https://images.unsplash.com/photo-1508873696983-2df5293cb395?w=600&auto=format&fit=crop&q=80',
      },
      {
        id: 'rec-2',
        date: '2026-01-14',
        type: 'Annual Inverter Calibration & Wash',
        technicianName: 'Senior Engr. Tariq Mehmood',
        efficiencyBefore: 81.0,
        efficiencyAfter: 99.1,
        notes: 'Tightened MC4 connections on String 2. Calibrated K-Electric bi-directional meter telemetry sync.',
      }
    ]
  },
  {
    id: 'sys-korangi',
    name: 'Korangi Industrial Textile Facility',
    clientName: 'Al-Karam Finishing Mills',
    location: 'Sector 7-A, Korangi Industrial Area, Karachi',
    zone: 'Korangi Industrial',
    capacityKW: 65.0,
    panelsCount: 118,
    inverterModel: 'Inverex Nitrox 50kW + 15kW Dual Array',
    systemType: 'Commercial Industrial',
    installationDate: 'November 2023',
    currentOutputKW: 46.2,
    dailyYieldKWh: 278.5,
    monthlySavingsPKR: 442000,
    dustSoilingLossPercent: 28.6,
    lastCleanedDate: '12 days ago',
    nextRecommendedCleanDate: 'In 3 days',
    inverterHealthScore: 89,
    gridVoltage: 402.1,
    gridFrequency: 49.95,
    mppt1Volts: 620.4,
    mppt2Volts: 618.9,
    inverterTempC: 51.2,
    history: [
      {
        id: 'rec-k1',
        date: '2026-04-04',
        type: 'High-Volume Commercial Rooftop Wash',
        technicianName: 'Industrial Mobile Team Alpha (4 Techs)',
        efficiencyBefore: 71.4,
        efficiencyAfter: 99.0,
        notes: 'Heavy particulate textile fluff and boiler exhaust soot washed with de-mineralized high-flow foam.',
      }
    ]
  },
  {
    id: 'sys-bahria',
    name: 'Bahria Town Luxury Villa',
    clientName: 'Sarah & Dr. Kamran Shotri',
    location: 'Precinct 10-A, Bahria Town Karachi (M-9)',
    zone: 'Malir',
    capacityKW: 16.0,
    panelsCount: 28,
    inverterModel: 'Growatt SPH 10000TL3 Hybrid + Dyness 10kWh Battery',
    systemType: 'Hybrid',
    installationDate: 'August 2024',
    currentOutputKW: 13.4,
    dailyYieldKWh: 71.8,
    monthlySavingsPKR: 118000,
    dustSoilingLossPercent: 18.2,
    lastCleanedDate: '18 days ago',
    nextRecommendedCleanDate: 'In 6 days',
    inverterHealthScore: 97,
    gridVoltage: 229.8,
    gridFrequency: 50.02,
    mppt1Volts: 492.1,
    mppt2Volts: 494.5,
    inverterTempC: 39.8,
    batterySOC: 88,
    history: [
      {
        id: 'rec-b1',
        date: '2026-03-29',
        type: 'Routine EcoPure Wash & Battery Health Test',
        technicianName: 'Engr. Bilal Farooq',
        efficiencyBefore: 82.5,
        efficiencyAfter: 98.7,
        notes: 'Dry desert wind sand accumulation washed. Dyness LiFePO4 battery cell balance verified at 99.2%.',
      }
    ]
  }
];

export const SCHEDULED_ALERTS: ScheduledAlert[] = [
  {
    id: 'alert-1',
    title: 'Karachi Coastal Silt & Dust Alert: -21.4% Loss',
    category: 'DUST_CLEANING',
    urgency: 'HIGH',
    description: 'High particulate PM2.5 and coastal sea breeze have formed a cementitious dust layer. Your 12.5 kW system is losing approx PKR 820 per day in ungenerated electricity.',
    systemName: 'DHA Phase 6 Residence',
    actionLabel: 'Schedule De-ionized Clean Now',
    actionType: 'BOOK_CLEAN',
    dateGenerated: 'Today, 06:30 AM',
    isRead: false
  },
  {
    id: 'alert-2',
    title: 'Bi-Annual Inverter Heat Sink & Terminal Audit Due',
    category: 'INVERTER_HEALTH',
    urgency: 'MEDIUM',
    description: 'Ambient temperatures in Karachi approaching 38°C. Ensure cooling fans and DC isolators are cleaned and torqued to avoid summer thermal throttling.',
    systemName: 'DHA Phase 6 Residence',
    actionLabel: 'Book Optimization Audit',
    actionType: 'BOOK_CLEAN',
    dateGenerated: '2 days ago',
    isRead: false
  },
  {
    id: 'alert-3',
    title: 'Weather Warning: High Humidity Sea Fog in South Karachi',
    category: 'WEATHER',
    urgency: 'INFO',
    description: 'Moisture combined with airborne dust will cause early morning baking on glass surfaces. Wash recommended before 10:00 AM.',
    systemName: 'All Coastal Systems',
    actionLabel: 'Check Weather Impact',
    actionType: 'VIEW_METRICS',
    dateGenerated: 'Yesterday',
    isRead: true
  }
];
